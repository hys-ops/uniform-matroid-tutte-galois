# Uniform Tutte Galois group: source and replay
This archive contains only the anonymous Tutte manuscript, its LaTeX source, 22 local Lean source modules and the archived run log. It does not contain the Euler manuscript or project. The verification script's temporary-directory prefix and help text are the only modifications to that script; the Lean source files are unchanged.

From the extracted archive:

    cd formal/tutte
    lake exe cache get
    lake build +Nyll.AnabelianGeometry.GeometricFundamentalGroup.AffineLineEtaleAlgebra
    lake env python3 verify.py --kernel

Requires Python 3, elan and Lean 4.36.0. Pinned mathlib: fc4f59e577feb1a4956671bc04ac18aaaf8cd842; NYLL: 30a178706c4828aa2c8e8d5c494c785be842af82. See formal/tutte/lake-manifest.json for transitive pins. A fresh local replay compiles the 22 project modules into a temporary directory, audits the 12 endpoints in Results.lean, and replays their declarations with leanchecker. It does not rebuild all of mathlib. The supplied verification.log records the original completed run; it is not a fresh replay of this archive packaging.

To typeset the anonymous LaTeX manuscript with a standard TeX Live installation, run pdflatex twice on Uniform_Tutte_Galois.tex from the manuscript folder.

Dependencies are obtained separately from upstream; no compiled objects are included.
