import UniformAtMinusOne
import UniformClear
import Mathlib.Algebra.Polynomial.Bivariate
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.RingTheory.Polynomial.GaussLemma

/-! Changes of degree when a bivariate polynomial is restricted to the
reciprocal diagonal. -/
namespace UniformIrreducible
open Polynomial
open scoped Polynomial.Bivariate
variable {K : Type*} [Field K]

theorem coeff_swap (P : (K[X])[X]) (i j : ℕ) :
    ((Bivariate.swap P).coeff i).coeff j = (P.coeff j).coeff i := by
  induction P using Polynomial.induction_on' with
  | add P Q ih jh => simp only [map_add, coeff_add, ih, jh]
  | monomial n q =>
    rw [Bivariate.swap_monomial, coeff_mul_C, coeff_map, ← C_mul_X_pow_eq_monomial]
    by_cases h : n=j
    · subst j; simp
    · simp [Ne.symm h]

theorem inner_degree_bound (P : (K[X])[X]) (j : ℕ) :
    (P.coeff j).natDegree ≤ (Bivariate.swap P).natDegree := by
  by_cases h : P.coeff j=0
  · simp [h]
  · apply le_natDegree_of_ne_zero
    intro hz
    have he := coeff_swap P (P.coeff j).natDegree j
    rw [hz,coeff_zero,coeff_natDegree] at he
    exact (leadingCoeff_ne_zero.mpr h) he.symm

theorem clear_degree_bound (P : (K[X])[X]) :
    (P.reverse.eval X).natDegree ≤ P.natDegree + (Bivariate.swap P).natDegree := by
  rw [eval_eq_sum_range]
  apply natDegree_sum_le_of_forall_le
  intro i hi
  apply natDegree_mul_le.trans
  rw [coeff_reverse,natDegree_X_pow]
  have h := inner_degree_bound P (Polynomial.revAt P.natDegree i)
  have := Finset.mem_range.mp hi
  have := P.reverse_natDegree_le
  omega

theorem swap_pencil (r s : ℕ) :
    Bivariate.swap (UniformGalois.pencil K r s) = UniformGalois.pencil K s r := by
  have h : (r+s).choose s = (r+s).choose r :=
    (Nat.choose_symm_of_eq_add (n:=r+s) (a:=r) (b:=s) rfl).symm
  simp only [UniformGalois.pencil,map_sub,Bivariate.swap_map_C,Bivariate.swap_C,
    map_natCast,Nat.add_comm s r,h]
  ring

theorem pencil_monic (r s : ℕ) (hr : 0 < r) : (UniformGalois.pencil K r s).Monic := by
  rw [Polynomial.Monic,leadingCoeff,UniformGalois.pencil_degree,UniformGalois.pencil,coeff_sub,
    coeff_map,UniformFibersAtRank.leading_at_rank,coeff_C]
  simp [hr.ne']

private theorem root_of_dvd_pow {g : K[X]} (n : ℕ) (hd : g ∣ (1+X)^n)
    (hn : 0 < g.natDegree) : g.eval (-1) = 0 := by
  have hp : Prime (1 + X : K[X]) := by
    simpa only [map_neg,map_one,sub_neg_eq_add,add_comm] using (prime_X_sub_C (-1:K))
  obtain ⟨i,_,hi⟩ := (dvd_prime_pow hp n).mp hd
  have hi0 : i ≠ 0 := by
    intro hi0
    rw [hi0,pow_zero,associated_one_iff_isUnit] at hi
    exact (not_isUnit_of_natDegree_pos g hn) hi
  have hdiv : (1+X:K[X]) ∣ g := (dvd_pow_self _ hi0).trans hi.symm.dvd
  obtain ⟨B,hB⟩ := hdiv
  simp [hB]

private theorem covanish_of_clear {P : (K[X])[X]} (hz : (P.reverse.eval X).eval (-1) = 0) :
    (P.map (evalRingHom (-1:K))).eval (-1) = 0 := by
  let f := evalRingHom (-1:K)
  have h : P.reverse.eval₂ f (-1) = 0 := by
    have he := Polynomial.eval₂_at_apply (p:=P.reverse) f (X:K[X])
    simpa [f] using he.trans hz
  rw [eval_map]
  let := invertibleOfNonzero (neg_ne_zero.mpr (one_ne_zero : (1:K) ≠ 0))
  apply (eval₂_reverse_eq_zero_iff f (-1:K) P).mp
  simpa using h

/-- Factor degrees saturate both poles after reciprocal substitution. Hence
each nonconstant factor would pass through the same smooth point. -/
theorem irreducible_of_clear [CharZero K] (r s : ℕ) (hr : 0<r) (hs : 0<s)
    (clearT : ((UniformGalois.pencil K r s).reverse.eval X) = (1+X)^(r+s)) :
    Irreducible (UniformGalois.pencil K r s) := by
  let T := UniformGalois.pencil K r s
  have degT : T.natDegree=r := UniformGalois.pencil_degree r s
  have T0 : T ≠ 0 := (pencil_monic r s hr).ne_zero
  apply irreducible_iff.mpr
  refine ⟨not_isUnit_of_natDegree_pos _ (by simpa [T,UniformGalois.pencil_degree] using hr),?_⟩
  intro A B h
  change T=A*B at h
  by_contra! hn
  have a₀ : A ≠ 0 := by intro he; exact T0 (by rw [h,he,zero_mul])
  have b₀ : B ≠ 0 := by intro he; exact T0 (by rw [h,he,mul_zero])
  have da : 0<A.natDegree := natDegree_pos_of_not_isUnit_of_dvd_monic
    (pencil_monic r s hr) hn.1 ⟨B,h⟩
  have db : 0<B.natDegree := natDegree_pos_of_not_isUnit_of_dvd_monic
    (pencil_monic r s hr) hn.2 ⟨A,h.trans (mul_comm A B)⟩
  have prod : A.reverse.eval X * B.reverse.eval X = (1+X)^(r+s) := by
    change T.reverse.eval X = (1+X)^(r+s) at clearT
    rwa [h, reverse_mul_of_domain,eval_mul] at clearT
  have degX : (1 + X : K[X]).natDegree = 1 := by
    rw [add_comm,← C_1,natDegree_X_add_C]
  have xx : (1 + X : K[X]) ≠ 0 := by
    intro he
    rw [he,natDegree_zero] at degX
    contradiction
  have clne := prod.trans_ne (pow_ne_zero (r+s) xx)
  obtain ⟨ca₀,cb₀⟩ := mul_ne_zero_iff.mp clne
  have dclear := congrArg Polynomial.natDegree prod
  rw [natDegree_mul ca₀ cb₀, natDegree_pow] at dclear
  rw [degX,mul_one] at dclear
  have dout := degT
  rw [h,natDegree_mul a₀ b₀] at dout
  have din : (Bivariate.swap T).natDegree=s := by
    rw [show Bivariate.swap T=UniformGalois.pencil K s r from swap_pencil r s,
      UniformGalois.pencil_degree]
  rw [h,map_mul,natDegree_mul ((map_ne_zero_iff Bivariate.swap Bivariate.swap.injective).mpr a₀)
      ((map_ne_zero_iff Bivariate.swap Bivariate.swap.injective).mpr b₀)] at din
  have ba := clear_degree_bound A
  have bb := clear_degree_bound B
  have ca : 0 < (A.reverse.eval X).natDegree := by omega
  have cb : 0 < (B.reverse.eval X).natDegree := by omega
  exact UniformAtMinusOne.factors_do_not_covanish r s hr hs A B h.symm
    (covanish_of_clear (root_of_dvd_pow (r+s) ⟨_,prod.symm⟩ ca))
    (covanish_of_clear (root_of_dvd_pow (r+s) ⟨_,prod.symm.trans (mul_comm _ _)⟩ cb))


/-- The translated uniform Tutte polynomial is irreducible as a bivariate
polynomial over every characteristic-zero field, including algebraically
closed fields. -/
theorem uniformAbsolutelyIrreducible [CharZero K] (r s : ℕ) (hr : 0<r) (hs : 0<s) :
    Irreducible (UniformGalois.pencil K r s) :=
  irreducible_of_clear r s hr hs (UniformClear.clear_pencil r s)

/-- Irreducibility over the generic parameter field, for any choice of a
fraction field of K[X]. -/
theorem uniformGenericIrreducible [CharZero K] (L : Type*) [Field L]
    [Algebra K[X] L] [IsFractionRing K[X] L] (r s : ℕ) (hr : 0<r) (hs : 0<s) :
    Irreducible ((UniformGalois.pencil K r s).map (algebraMap K[X] L)) :=
  (Polynomial.IsPrimitive.irreducible_iff_irreducible_map_fraction_map
    (K:=L) (pencil_monic r s hr).isPrimitive).mp (uniformAbsolutelyIrreducible r s hr hs)

#print axioms uniformGenericIrreducible
#print axioms uniformAbsolutelyIrreducible
end UniformIrreducible
