import UniformFibersAtRank
import Mathlib.Algebra.BigOperators.Group.Finset.Powerset
import Mathlib.Algebra.BigOperators.Intervals

/-! The rank-nullity subset sum of a uniform matroid and the two binomial
sections that define its one-variable fibers. -/
namespace UniformSubsetTutte
open Finset Polynomial UniformBinomial
open scoped BigOperators

/-- Evaluation of a Tutte polynomial from the rank on subsets of a finite
ground set. The variables supplied here are the ordinary unshifted variables. -/
noncomputable def fromRank {α R : Type*} [CommRing R] (E : Finset α)
    (rk : Finset α → ℕ) (x y : R) : R :=
  ∑ A ∈ E.powerset, (x-1)^(rk E - rk A) * (y-1)^(A.card-rk A)

/-- Uniform matroid rank function on finite subsets, including rank 0. -/
def uniformRank {α : Type*} (r : ℕ) (A : Finset α) : ℕ := min r A.card

/-- The reversed binomial section can be evaluated over any commutative ring. -/
def sectionValue {R : Type*} [CommSemiring R] (n r : ℕ) (u : R) : R :=
  ∑ j ∈ range (r+1), u^(r-j)*(n.choose j:R)

theorem by_cardinality {α R : Type*} [CommSemiring R] (E : Finset α) (w : ℕ → R) :
    ∑ A ∈ E.powerset, w A.card = ∑ j ∈ range (E.card+1), (E.card.choose j:R)*w j := by
  rw [Finset.sum_powerset]
  apply Finset.sum_congr rfl
  intro j _
  simpa [nsmul_eq_mul] using Finset.sum_powersetCard j E w

theorem split_by_rank {R : Type*} [CommRing R] (r s : ℕ) (u v : R) :
    (∑ j ∈ range (r+s+1), ((r+s).choose j:R)*u^(r-min r j)*v^(j-min r j)) =
      sectionValue (r+s) r u + sectionValue (r+s) s v - ((r+s).choose r : R) := by
  let n := r+s
  let f (j : ℕ) := (n.choose j:R)*u^(r-min r j)*v^(j-min r j)
  change (∑ j ∈ range (r+s+1), f j) = _
  rw [Nat.add_assoc, Finset.sum_range_add]
  have low : (∑ j ∈ range r, f j) = ∑ j ∈ range r, u^(r-j)*(n.choose j:R) := by
    apply Finset.sum_congr rfl
    intro j hj
    have hj' : j ≤ r := (Finset.mem_range.mp hj).le
    simp [f,min_eq_right hj',mul_comm]
  have high : (∑ j ∈ range (s+1), f (r+j)) = sectionValue n s v := by
    rw [← Finset.sum_range_reflect (fun j => f (r+j)) (s+1)]
    unfold sectionValue
    apply Finset.sum_congr rfl
    intro j hj
    have hj' : j ≤ s := by simpa using hj
    have hidx : r+((s+1)-1-j) = n-j := by dsimp [n]; omega
    have hle : r ≤ n-j := by dsimp [n]; omega
    have hjn : j ≤ n := by dsimp [n]; omega
    have hsub : n-j-r = s-j := by dsimp [n]; omega
    rw [hidx]
    simp [f,min_eq_left hle,hsub,Nat.choose_symm hjn,mul_comm]
  rw [low,high]
  change _ = sectionValue n r u + sectionValue n s v - (n.choose r:R)
  unfold sectionValue
  rw [Finset.sum_range_succ (f := fun j => u^(r-j)*(n.choose j:R))]
  simp only [Nat.sub_self,pow_zero,one_mul]
  ring

/-- This is the defining subset-rank sum, valid over every commutative ring
and on every finite ground set of size r+s. -/
theorem subset_tutte {α R : Type*} [CommRing R] (E : Finset α) (r s : ℕ)
    (hE : E.card = r+s) (x y : R) :
    fromRank E (uniformRank r) x y =
      sectionValue (r+s) r (x-1) + sectionValue (r+s) s (y-1) - ((r+s).choose r:R) := by
  unfold fromRank uniformRank
  rw [hE,min_eq_left (by omega : r ≤ r+s)]
  have h := by_cardinality (R:=R) E (fun j => (x-1)^(r-min r j)*(y-1)^(j-min r j))
  rw [h,hE]
  simpa only [mul_assoc] using split_by_rank r s (x-1) (y-1)

theorem F_eval_eq_sectionValue {K : Type*} [Field K] (n r : ℕ) (u : K) :
    (F K n r).eval u = sectionValue n r u := by
  rw [F_eq_sum,sectionValue]
  simp [eval_finsetSum]

theorem finite_uniform_tutte {K : Type*} [Field K] (r s : ℕ) (x y : K) :
    fromRank (univ : Finset (Fin (r+s))) (uniformRank r) x y =
      (F K (r+s) r).eval (x-1) + (F K (r+s) s).eval (y-1) - ((r+s).choose r:K) := by
  simpa only [F_eval_eq_sectionValue] using
    subset_tutte (univ : Finset (Fin (r+s))) r s (by simp) x y


theorem map_section {R S : Type*} [CommSemiring R] [CommSemiring S]
    (g : R →+* S) (n r : ℕ) (u : R) : g (sectionValue n r u) = sectionValue n r (g u) := by
  simp [sectionValue,map_sum]

/-- Equality as polynomials, so the formula also specializes correctly over
finite fields without invoking equality of polynomial functions. -/
theorem exact_fiber {K : Type*} [Field K] (r s : ℕ) (v : K) :
    fromRank (univ : Finset (Fin (r+s))) (uniformRank r) (X+1 : K[X]) (C v+1) =
      UniformFibersAtRank.tutteFiber r s v := by
  rw [subset_tutte (univ : Finset (Fin (r+s))) r s (by simp)]
  simp only [add_sub_cancel_right]
  rw [← map_section C]
  change sectionValue (r+s) r (X : K[X]) + C (sectionValue (r+s) s v) - _ = _
  rw [← F_eval_eq_sectionValue, UniformFibersAtRank.tutteFiber]
  have h : sectionValue (r+s) r (X : K[X]) = F K (r+s) r := (F_eq_sum _ _).symm
  rw [h,map_sub]
  simp
  abel

#print axioms exact_fiber

end UniformSubsetTutte
