import UniformGlobal
import UniformOrdinary
import UniformMatroidModel

/-! The Bohn–Cameron–Müller statement on every positive-rank, positive-corank
uniform matroid, with the actual Matroid, rank sum and original coordinates. -/
namespace UniformMatroidGalois
open Polynomial UniformMatroidModel
noncomputable section
universe u
variable (K : Type u) [Field K] [CharZero K]

/-- The standard two-variable Tutte polynomial T_U(X,y), considered over K(y). -/
def polynomial (r n : ℕ) : (RatFunc K)[X] :=
  tutte (uniform (Fin n) r) X (C (UniformOrdinary.y K))

omit [CharZero K] in
private theorem rank_sum_eq (r s : ℕ) :
    polynomial K r (r+s) = UniformOrdinary.tutte K r s := by
  classical
  unfold polynomial tutte UniformOrdinary.tutte
  have hg : (uniform (Fin (r+s)) r).E.toFinset = Finset.univ := by
    ext x
    rw [Set.mem_toFinset,uniform_ground]
    simp
  rw [hg]
  congr 1
  funext A
  rw [rank_eq, ENat.toNat_natCast]
  rfl

local instance splittingFact {F : Type*} [Field F] (p : F[X]) :
    Fact ((p.map (algebraMap F p.SplittingField)).Splits) := ⟨SplittingField.splits p⟩

private theorem order_pencil (r s : ℕ) (hr : 0<r) (hs : 0<s) :
    Nat.card (UniformSplitting.generic K r s).Gal = r.factorial := by
  have h := Nat.card_congr (UniformGlobal.uniform_tutte_galois K r s hr hs).toEquiv
  have hp : Nat.card (Equiv.Perm (Fin r)) = r.factorial := by
    rw [Nat.card_eq_fintype_card, Fintype.card_perm, Fintype.card_fin]
  exact h.trans hp

theorem roots (r n : ℕ) (hr : 0<r) (hn : r<n) :
    Fintype.card ((polynomial K r n).rootSet (polynomial K r n).SplittingField) = r := by
  obtain ⟨s, rfl⟩ := Nat.exists_eq_add_of_le hn.le
  rw [rank_sum_eq]
  exact UniformOrdinary.roots_card K r s hr (by omega)

/-- The natural action on the actual roots realizes all r! permutations. -/
theorem action (r n : ℕ) (hr : 0<r) (hn : r<n) :
    Function.Bijective (Gal.galActionHom (polynomial K r n) (polynomial K r n).SplittingField) := by
  obtain ⟨s, rfl⟩ := Nat.exists_eq_add_of_le hn.le
  rw [rank_sum_eq]
  exact UniformOrdinary.full_action_of_order K r s hr (by omega) (order_pencil K r s hr (by omega))

/-- The Galois group of the ordinary Tutte polynomial of U_(r,n) over K(y)
is the full symmetric group S_r for every characteristic-zero field K and 0<r<n. -/
def uniform_tutte_galois (r n : ℕ) (hr : 0<r) (hn : r<n) :
    (polynomial K r n).Gal ≃* Equiv.Perm (Fin r) :=
  (MulEquiv.ofBijective _ (action K r n hr hn)).trans
    (Fintype.equivFinOfCardEq (roots K r n hr hn)).permCongrHom

end
end UniformMatroidGalois
