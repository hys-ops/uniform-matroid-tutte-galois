import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Data.Nat.Choose.Sum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.LinearCombination

/-! Identities for reverse binomial truncations, including both endpoints. -/
namespace UniformBinomial

open Polynomial
open scoped Polynomial BigOperators

variable {K : Type*} [Field K]

/-- Horner form for the reversed section of the binomial expansion. -/
noncomputable def F (K : Type*) [Field K] (n : ℕ) : ℕ → K[X]
  | 0 => 1
  | r+1 => X * F K n r + (n.choose (r+1) : K[X])

/-- The recursion is exactly the usual truncated binomial sum. -/
theorem F_eq_sum (n r : ℕ) :
    F K n r = ∑ k ∈ Finset.range (r+1), X ^ (r-k) * (n.choose k : K[X]) := by
  induction r with
  | zero => simp [F]
  | succ r ih =>
    rw [F, ih, Finset.mul_sum]
    conv_rhs => rw [Finset.sum_range_succ]
    simp only [Nat.sub_self, pow_zero, one_mul]
    congr 1
    apply Finset.sum_congr rfl
    intro k hk
    have h : r + 1 - k = (r-k)+1 := by
      have := Finset.mem_range.mp hk
      omega
    rw [h, pow_succ']
    ring

theorem F_self (n : ℕ) : F K n n = (1 + X)^n := by
  rw [F_eq_sum, add_pow]
  simp

/-- Polynomial differential identity valid uniformly in the truncation and its complement. -/
theorem differential (r s : ℕ) :
    X * (X+1) * (F K (r+s) r).derivative =
      ((r : K[X])*X-(s : K[X])) * F K (r+s) r + (s : K[X])*((r+s).choose r : K[X]) := by
  induction r generalizing s with
  | zero => simp [F]
  | succ r ih =>
    let n := r + 1 + s
    have hn : n = r + (s+1) := by dsimp [n]; omega
    have h := ih (s+1)
    rw [← hn] at h
    have hcN := Nat.choose_succ_right_eq n r
    have hs : n - r = s+1 := by dsimp [n]; omega
    rw [hs] at hcN
    have hc : (n.choose (r+1) : K[X]) * (r+1 : ℕ) =
        (n.choose r : K[X]) * (s+1 : ℕ) := by
      simpa only [Nat.cast_mul] using congrArg (fun a : ℕ => (a : K[X])) hcN
    change X*(X+1)*(F K n (r+1)).derivative =
      (((r+1 : ℕ) : K[X])*X-(s : K[X])) * F K n (r+1) + (s : K[X])*(n.choose (r+1) : K[X])
    rw [F, derivative_add, derivative_mul]
    simp only [derivative_X, one_mul, derivative_natCast, add_zero]
    push_cast at h hc ⊢
    linear_combination X * h - X * hc

/-- Reciprocal splitting of the full binomial expansion, with the shared term subtracted once. -/
theorem reciprocal (r s : ℕ) (z : K) (hz : z ≠ 0) :
    z^s * ((F K (r+s) r).eval z + (F K (r+s) s).eval z⁻¹ - ((r+s).choose r : K))
       = (1+z)^(r+s) := by
  induction r generalizing s with
  | zero =>
    simp only [Nat.zero_add, F, eval_one, Nat.choose_zero_right, Nat.cast_one]
    rw [F_self]
    simp only [eval_pow, eval_add, eval_one, eval_X]
    rw [add_sub_cancel_left, ← mul_pow]
    have h : z * (1 + z⁻¹) = 1+z := by field_simp; ring
    rw [h]
  | succ r ih =>
    let n := r + 1 + s
    have hn : n = r + (s+1) := by dsimp [n]; omega
    have h := ih (s+1)
    rw [← hn] at h
    have hc : n.choose (s+1) = n.choose r := (Nat.choose_symm_of_eq_add hn).symm
    change z^s * ((F K n (r+1)).eval z + (F K n s).eval z⁻¹ - (n.choose (r+1) : K)) = (1+z)^n
    rw [F, eval_add, eval_mul, eval_X, eval_natCast]
    rw [F, eval_add, eval_mul, eval_X, eval_natCast, hc, pow_succ] at h
    rw [← h]
    field_simp
    ring

/-- Pointwise form of the polynomial identity, ready for specializing at a critical point. -/
theorem eval_differential (r s : ℕ) (z : K) :
    z*(z+1)*(F K (r+s) r).derivative.eval z =
      ((r : K)*z-(s : K))*(F K (r+s) r).eval z + (s : K)*((r+s).choose r : K) := by
  have h := congrArg (Polynomial.eval z) (differential (K := K) r s)
  simpa only [eval_mul, eval_add, eval_X, eval_one, eval_sub, eval_natCast] using h

theorem reciprocal_div (r s : ℕ) (z : K) (hz : z ≠ 0) :
    (F K (r+s) r).eval z + (F K (r+s) s).eval z⁻¹ - ((r+s).choose r : K)
      = (1+z)^(r+s) / z^s := by
  apply (eq_div_iff (pow_ne_zero _ hz)).2
  rw [mul_comm]
  exact reciprocal r s z hz

end UniformBinomial
