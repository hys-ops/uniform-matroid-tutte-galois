import UniformBaseChange
import AffineInertiaEtale
import Nyll.AnabelianGeometry.GeometricFundamentalGroup.AffineLineEtaleAlgebra
import Mathlib.FieldTheory.IsAlgClosed.AlgebraicClosure

/-! Uniform Tutte polynomials have the full symmetric Galois group on their
r roots over the rational function field of every characteristic-zero field. -/
namespace UniformGlobal
open Polynomial UniformSplitting AnabelianGeometry.GeometricFundamentalGroup
noncomputable section
universe u

theorem affine_inertia_generates (K L : Type u) [Field K] [IsAlgClosed K] [CharZero K]
    [Field L] [Algebra (RatFunc K) L] [Algebra K L] [IsScalarTower K (RatFunc K) L]
    [Algebra K[X] L] [IsScalarTower K[X] (RatFunc K) L]
    [FiniteDimensional (RatFunc K) L] [IsGalois (RatFunc K) L]
    [MulSemiringAction Gal(L/RatFunc K) (integralClosure K[X] L)]
    [SMulDistribClass Gal(L/RatFunc K) (integralClosure K[X] L) L] :
    ⨆ m : MaximalSpectrum (integralClosure K[X] L), m.asIdeal.inertia Gal(L/RatFunc K) = ⊤ := by
  classical
  let H := ⨆ m : MaximalSpectrum (integralClosure K[X] L), m.asIdeal.inertia Gal(L/RatFunc K)
  let M := IntermediateField.fixedField H
  have he := AffineInertiaEtale.iSup_fixedField_etale K L
  have hb := bijective_algebraMap_of_etale_polynomial_normalization (K:=K) (E:=M) he
  have hbot : M = ⊥ := by
    apply bot_unique
    intro x hx
    obtain ⟨y,hy⟩ := hb.surjective (⟨x,hx⟩ : M)
    exact IntermediateField.mem_bot.mpr ⟨y,congrArg Subtype.val hy⟩
  change H = ⊤
  rw [← IntermediateField.fixingSubgroup_fixedField H, show IntermediateField.fixedField H = ⊥ from hbot,
    IntermediateField.fixingSubgroup_bot]

theorem geometric (K : Type u) [Field K] [IsAlgClosed K] [CharZero K]
    (r s : ℕ) (hr : 0 < r) (hs : 0 < s) :
    Function.Bijective (MulAction.toPermHom (splitting K r s ≃ₐ[RatFunc K] splitting K r s)
      ((generic K r s).rootSet (splitting K r s))) := by
  apply UniformActual.actual_root_action_of_inertia r s hr hs
  let : IsGalois (RatFunc K) (splitting K r s) :=
    IsGalois.of_separable_splitting_field
      (UniformIrreducible.uniformGenericIrreducible (K:=K) (RatFunc K) r s hr hs).separable
  exact affine_inertia_generates K (splitting K r s)

theorem arithmetic (K : Type u) [Field K] [CharZero K] (r s : ℕ) (hr : 0 < r) (hs : 0 < s) :
    Function.Bijective (MulAction.toPermHom (splitting K r s ≃ₐ[RatFunc K] splitting K r s)
      ((generic K r s).rootSet (splitting K r s))) :=
  UniformBaseChange.full_of_constant_extension K (AlgebraicClosure K) r s hr hs
    (geometric (AlgebraicClosure K) r s hr hs).surjective

def uniform_tutte_galois (K : Type u) [Field K] [CharZero K] (r s : ℕ) (hr : 0 < r) (hs : 0 < s) :
    (splitting K r s ≃ₐ[RatFunc K] splitting K r s) ≃* Equiv.Perm (Fin r) :=
  (MulEquiv.ofBijective _ (arithmetic K r s hr hs)).trans
    (Fintype.equivFinOfCardEq (UniformActual.field_root_count (K:=K) r s hr hs)).permCongrHom

#print axioms uniform_tutte_galois
end
end UniformGlobal
