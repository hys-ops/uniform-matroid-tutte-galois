import AffineInertiaIndex
import AffineEtaleBridge

/-! The square-bracketed Galois action in the first result may be chosen to be
the integral restriction of the field automorphisms, as in the second result. -/
namespace AffineInertiaEtale
open Polynomial

variable (k L : Type*) [Field k] [CharZero k] [Field L] [Algebra (RatFunc k) L]
    [Algebra k[X] L] [IsScalarTower k[X] (RatFunc k) L]
    [FiniteDimensional (RatFunc k) L] [IsGalois (RatFunc k) L]

/-- The affine normalization in the common fixed field of all finite inertia
groups is étale. The assertion makes no assumption on the place at infinity. -/
theorem iSup_fixedField_etale [MulSemiringAction Gal(L/RatFunc k) (integralClosure k[X] L)]
    [SMulDistribClass Gal(L/RatFunc k) (integralClosure k[X] L) L] :
    Algebra.Etale k[X] (integralClosure k[X] (IntermediateField.fixedField
      (⨆ m : MaximalSpectrum (integralClosure k[X] L), m.asIdeal.inertia Gal(L/RatFunc k)))) := by
  apply AffineEtaleBridge.integralClosure_etale k
  exact AffineInertiaIndex.fixedField_index k k[X] (RatFunc k) L _
    (fun m => le_iSup (fun t : MaximalSpectrum (integralClosure k[X] L) =>
      t.asIdeal.inertia Gal(L/RatFunc k)) m)

/-- The preceding result with the action obtained by restricting each field
automorphism to the integral closure of the polynomial ring. -/
theorem canonical_fixedField_etale :
    letI : IsFractionRing (integralClosure k[X] L) L :=
      integralClosure.isFractionRing_of_finite_extension (A:=k[X]) (RatFunc k) L
    letI := IsIntegralClosure.MulSemiringAction k[X] (RatFunc k) L (integralClosure k[X] L)
    Algebra.Etale k[X] (integralClosure k[X] (IntermediateField.fixedField
      (⨆ m : MaximalSpectrum (integralClosure k[X] L), m.asIdeal.inertia Gal(L/RatFunc k)))) := by
  let : IsFractionRing (integralClosure k[X] L) L :=
    integralClosure.isFractionRing_of_finite_extension (A:=k[X]) (RatFunc k) L
  let := IsIntegralClosure.MulSemiringAction k[X] (RatFunc k) L (integralClosure k[X] L)
  exact iSup_fixedField_etale k L

end AffineInertiaEtale
