import UniformBinomial
import Mathlib.Tactic.Ring
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.FieldSimp

/-! Critical points of the truncated binomial polynomials of uniform matroids.
    The Galois and covering-space steps are outside these algebraic lemmas. -/
namespace UniformCritical
open Polynomial
variable {K : Type*} [Field K]

/-- The polynomial equation whose critical values are controlled by the ODE. -/
def Satisfies (f : K[X]) (r s c : K) : Prop :=
    X * (X + 1) * derivative f = (C r * X - C s) * f + C (s * c)

theorem F_satisfies (r s : ℕ) :
    Satisfies (UniformBinomial.F K (r+s) r) (r : K) (s : K) ((r+s).choose r : K) := by
  simpa [Satisfies, map_mul, Polynomial.C_eq_natCast] using
    (UniformBinomial.differential (K := K) r s)

/-- At f'(a)=0 the ODE computes f(a) and the differentiated ODE computes f''(a). -/
theorem critical_identities {f : K[X]} {r s c a : K} (h : Satisfies f r s c)
    (ha : (derivative f).eval a = 0) :
    (s - r*a) * f.eval a = s*c ∧
    a*(a+1) * (derivative (derivative f)).eval a = r * f.eval a := by
  change X * (X + 1) * derivative f = (C r * X - C s) * f + C (s * c) at h
  have e := congrArg (eval a) h
  have d := congrArg (fun p : K[X] => (derivative p).eval a) h
  simp [derivative_mul, derivative_sub, derivative_add, ha] at e d
  constructor
  · linear_combination e
  · linear_combination d

theorem critical_nonzero {f : K[X]} {r s c a : K} (h : Satisfies f r s c)
    (hr : r ≠ 0) (hs : s ≠ 0) (hc : c ≠ 0) (ha : (derivative f).eval a = 0) :
    f.eval a ≠ 0 ∧ a ≠ 0 ∧ a+1 ≠ 0 ∧ (derivative (derivative f)).eval a ≠ 0 := by
  obtain ⟨e,d⟩ := critical_identities h ha
  have hv : f.eval a ≠ 0 := by
    intro H
    exact (mul_ne_zero hs hc) (by simpa [H] using e.symm)
  have hn : a*(a+1)*(derivative (derivative f)).eval a ≠ 0 :=
    d.symm ▸ mul_ne_zero hr hv
  rcases mul_ne_zero_iff.mp hn with ⟨hh,h2⟩
  exact ⟨hv, (mul_ne_zero_iff.mp hh).1, (mul_ne_zero_iff.mp hh).2, h2⟩

theorem distinct_critical_values {f : K[X]} {r s c a b : K}
    (h : Satisfies f r s c) (hr : r ≠ 0) (hs : s ≠ 0) (hc : c ≠ 0)
    (ha : (derivative f).eval a = 0) (hb : (derivative f).eval b = 0)
    (hv : f.eval a = f.eval b) : a = b := by
  obtain ⟨ea,_⟩ := critical_identities h ha
  obtain ⟨eb,_⟩ := critical_identities h hb
  rw [← hv] at eb
  have hprod : r * f.eval a * (a-b) = 0 := by linear_combination eb - ea
  exact sub_eq_zero.mp ((mul_eq_zero.mp hprod).resolve_left
    (mul_ne_zero hr (critical_nonzero h hr hs hc ha).1))

/-- Complementary ranks force any putative collision onto the reciprocal diagonal. -/
theorem reciprocal_of_collision {f g : K[X]} {r s c a b : K}
    (hf : Satisfies f r s c) (hg : Satisfies g s r c)
    (hr : r ≠ 0) (hs : s ≠ 0) (hc : c ≠ 0)
    (ha : (derivative f).eval a = 0) (hb : (derivative g).eval b = 0)
    (he : f.eval a + g.eval b = c) : a*b = 1 := by
  obtain ⟨ea,_⟩ := critical_identities hf ha
  obtain ⟨eb,_⟩ := critical_identities hg hb
  have hprod : r*s*c*(a*b-1) = 0 := by
    linear_combination (r-s*b) * ea + (s-r*a) * eb - (s-r*a)*(r-s*b)*he
  exact sub_eq_zero.mp ((mul_eq_zero.mp hprod).resolve_left
    (mul_ne_zero (mul_ne_zero hr hs) hc))

/-- Applied to the complementary binomial sections, the displayed reciprocal identity
    for their sum rules out every common finite branch value. -/
theorem disjoint_of_reciprocal_identity {f g : K[X]} {r s c : K}
    (hf : Satisfies f r s c) (hg : Satisfies g s r c)
    (hr : r ≠ 0) (hs : s ≠ 0) (hc : c ≠ 0) (m n : ℕ)
    (hrec : ∀ a : K, a ≠ 0 →
      a^m * (f.eval a + g.eval a⁻¹ - c) = (a+1)^n)
    {a b : K} (ha : (derivative f).eval a = 0) (hb : (derivative g).eval b = 0) :
    f.eval a + g.eval b ≠ c := by
  intro he
  have ⟨_,h0,h1,_⟩ := critical_nonzero hf hr hs hc ha
  have hprod := reciprocal_of_collision hf hg hr hs hc ha hb he
  have hi : b = a⁻¹ := by
    calc
      b = a⁻¹ * (a*b) := by field_simp
      _ = a⁻¹ := by rw [hprod, mul_one]
  have hzero := hrec a h0
  rw [← hi, he, sub_self, mul_zero] at hzero
  exact (pow_ne_zero _ h1) hzero.symm

/-- In characteristic zero, the reversed binomial section and its reflected complement
    have disjoint finite branch values at every pair of positive complementary ranks. -/
theorem uniform_critical_values_disjoint [CharZero K] (r s : ℕ)
    (hr : 0 < r) (hs : 0 < s) {a b : K}
    (ha : (UniformBinomial.F K (r+s) r).derivative.eval a = 0)
    (hb : (UniformBinomial.F K (r+s) s).derivative.eval b = 0) :
    (UniformBinomial.F K (r+s) r).eval a + (UniformBinomial.F K (r+s) s).eval b ≠
      ((r+s).choose r : K) := by
  have hc : ((r+s).choose r : K) ≠ 0 :=
    Nat.cast_ne_zero.mpr (Nat.choose_pos (Nat.le_add_right r s)).ne'
  have hsym : (r+s).choose s = (r+s).choose r :=
    (Nat.choose_symm_of_eq_add (n := r+s) (a := r) (b := s) rfl).symm
  have hg : Satisfies (UniformBinomial.F K (r+s) s) (s:K) (r:K) ((r+s).choose r : K) := by
    simpa only [Nat.add_comm s r, hsym] using (F_satisfies (K:=K) s r)
  apply disjoint_of_reciprocal_identity (F_satisfies (K:=K) r s) hg
    (Nat.cast_ne_zero.mpr hr.ne') (Nat.cast_ne_zero.mpr hs.ne') hc s (r+s) _ ha hb
  intro z hz
  simpa only [add_comm z 1] using UniformBinomial.reciprocal r s z hz

end UniformCritical
