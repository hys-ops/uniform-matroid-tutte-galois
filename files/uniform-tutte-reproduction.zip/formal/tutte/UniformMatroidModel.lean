import UniformSubsetTutte
import Mathlib.Combinatorics.Matroid.IndepAxioms
import Mathlib.Combinatorics.Matroid.Rank.ENat

/-! Bundled uniform matroid, constructed from the independence axioms. -/
namespace UniformMatroidModel
open Finset Polynomial UniformSubsetTutte

private def axioms (α : Type*) [DecidableEq α] (r : ℕ) : IndepMatroid α :=
  IndepMatroid.ofFinset Set.univ (fun A => A.card ≤ r)
    (by simp) (by intro I J h hsub; exact (Finset.card_le_card hsub).trans h)
    (by
      intro I J _ hJ hsize
      obtain ⟨x,hx,hxi⟩ := Finset.exists_mem_notMem_of_card_lt_card hsize
      exact ⟨x,hx,hxi, by simpa [Finset.card_insert_of_notMem hxi] using
        (show I.card+1 ≤ r from by omega)⟩)
    (by intro I _; exact Set.subset_univ _)

/-- All and only the finite sets of at most r elements are independent. -/
noncomputable def uniform (α : Type*) [DecidableEq α] (r : ℕ) : Matroid α :=
  (axioms α r).matroid

theorem indep_iff {α : Type*} [DecidableEq α] (r : ℕ) (A : Finset α) :
    (uniform α r).Indep A ↔ A.card ≤ r := by
  rw [uniform,IndepMatroid.matroid_indep_iff]; unfold axioms
  apply IndepMatroid.ofFinset_indep

theorem rank_eq {α : Type*} [DecidableEq α] (r : ℕ) (A : Finset α) :
    (uniform α r).eRk A = (min r A.card:ℕ) := by
  classical
  let M := uniform α r
  change M.eRk A = _
  apply le_antisymm
  · obtain ⟨I,hI⟩ := M.exists_isBasis' (A:Set α)
    have hf : I.Finite := A.finite_toSet.subset hI.subset
    have hJ : M.Indep ((hf.toFinset : Finset α):Set α) := by simpa using hI.indep
    have ub := (indep_iff r hf.toFinset).mp hJ
    have ub' : hf.toFinset.card ≤ A.card := Finset.card_le_card (by
      intro a ha; exact hI.subset (by simpa using ha))
    rw [← hI.encard_eq_eRk, hf.encard_eq_coe_toFinset_card]
    exact_mod_cast le_min ub ub'
  · obtain ⟨B,hB,hcard⟩ := Finset.exists_subset_card_eq (min_le_right r A.card)
    have hi := (indep_iff r B).mpr (hcard ▸ min_le_left _ _)
    have he := M.eRk_mono (show (B:Set α) ⊆ A from hB)
    change (uniform α r).eRk B ≤ _ at he
    rw [hi.eRk_eq_encard,Set.encard_coe_eq_coe_finsetCard,hcard] at he
    exact he


/-- Standard rank-nullity evaluation for a bundled finite-ground matroid. -/
noncomputable def tutte {α R : Type*} [Fintype α] [CommRing R] (M : Matroid α)
    (x y : R) : R := by
  classical
  exact fromRank M.E.toFinset (fun A => (M.eRk A).toNat) x y

theorem uniform_ground (α : Type*) [DecidableEq α] (r : ℕ) :
    (uniform α r).E=Set.univ := rfl

/-- The actual bundled uniform matroid yields precisely the polynomial fiber
used in the critical-value and root-multiplicity calculations. -/
theorem tutte_uniform_fiber {K : Type*} [Field K] (r s : ℕ) (v : K) :
    tutte (uniform (Fin (r+s)) r) (X+1 : K[X]) (C v+1) =
      UniformFibersAtRank.tutteFiber r s v := by
  classical
  unfold tutte
  have hg : (uniform (Fin (r+s)) r).E.toFinset = univ := by
    ext x
    rw [Set.mem_toFinset,uniform_ground]
    simp
  rw [hg]
  have hr : (fun A : Finset (Fin (r+s)) => ((uniform (Fin (r+s)) r).eRk A).toNat)
      = uniformRank r := by
    funext A
    rw [rank_eq,ENat.toNat_natCast]; rfl
  rw [hr]
  exact exact_fiber r s v

#print axioms tutte_uniform_fiber

end UniformMatroidModel
