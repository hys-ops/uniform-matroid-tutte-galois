import UniformActual

/-! Extending the coefficient field embeds a polynomial's new Galois group
into its original Galois group. Here the root actions are the actual actions
on the splitting fields of the two polynomials. -/
namespace UniformBaseChange
open Polynomial
noncomputable section

theorem card_map_gal_le {F E : Type*} [Field F] [Field E] [Algebra F E] (p : F[X]) :
    Nat.card (p.map (algebraMap F E)).Gal ≤ Nat.card p.Gal := by
  classical
  let q := p.map (algebraMap F E)
  let L := q.SplittingField
  have hmap : q.map (algebraMap E L) = p.map (algebraMap F L) := by
    change (p.map (algebraMap F E)).map (algebraMap E L) = _
    rw [Polynomial.map_map, ← IsScalarTower.algebraMap_eq]
  let : Fact ((p.map (algebraMap F L)).Splits) := ⟨hmap ▸ SplittingField.splits q⟩
  let restrict : q.Gal → p.Gal := fun σ =>
    Gal.restrict p L ((show L ≃ₐ[E] L from σ).restrictScalars F)
  apply Nat.card_le_card_of_injective restrict
  intro σ τ h
  apply Gal.ext q
  intro x hx
  have hx' : x ∈ p.rootSet L := by
    simpa only [Polynomial.rootSet_def,Polynomial.aroots_def,← hmap] using hx
  let v : p.rootSet L := ⟨x,hx'⟩
  have he := congrArg (fun g : p.Gal => ((Gal.galActionHom p L g v : p.rootSet L) : L)) h
  simp only [restrict,Gal.galActionHom_restrict] at he
  exact he

private def extendConstants (K k : Type*) [Field K] [Field k] [Algebra K k] :
    RatFunc K →+* RatFunc k :=
  IsFractionRing.map (j:=Polynomial.mapRingHom (algebraMap K k))
    (Polynomial.map_injective (algebraMap K k) (algebraMap K k).injective)

open UniformSplitting

theorem map_generic (K k : Type*) [Field K] [Field k] [Algebra K k] (r s : ℕ) :
    (generic K r s).map (extendConstants K k) = generic k r s := by
  rw [generic,generic,Polynomial.map_map,UniformGalois.map_pencil,UniformGalois.map_pencil]
  simp [RingHom.comp_apply,extendConstants,IsFractionRing.map]

theorem full_of_constant_extension (K k : Type*) [Field K] [Field k] [Algebra K k]
    [CharZero K] [CharZero k] (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (h : Function.Surjective (MulAction.toPermHom (splitting k r s ≃ₐ[RatFunc k] splitting k r s)
      ((generic k r s).rootSet (splitting k r s)))) :
    Function.Bijective (MulAction.toPermHom (splitting K r s ≃ₐ[RatFunc K] splitting K r s)
      ((generic K r s).rootSet (splitting K r s))) := by
  classical
  let : Algebra (RatFunc K) (RatFunc k) := (extendConstants K k).toAlgebra
  have hle := card_map_gal_le (E:=RatFunc k) (generic K r s)
  change Nat.card (Polynomial.map (extendConstants K k) (generic K r s)).Gal ≤ _ at hle
  rw [map_generic,Nat.card_eq_fintype_card,Nat.card_eq_fintype_card] at hle
  have hsurl := Fintype.card_le_of_surjective _ h
  have hw := UniformActual.field_root_count (K:=K) r s hr hs
  have hw' := UniformActual.field_root_count (K:=k) r s hr hs
  rw [Fintype.card_perm,hw'] at hsurl
  have hinj : Function.Injective (MulAction.toPermHom
      (splitting K r s ≃ₐ[RatFunc K] splitting K r s) ((generic K r s).rootSet (splitting K r s))) := by
    intro g g' he
    apply Gal.ext (generic K r s)
    intro x hx
    let v : (generic K r s).rootSet (splitting K r s) := ⟨x,hx⟩
    exact congrArg Subtype.val (congrArg (fun e : Equiv.Perm _ => e v) he)
  apply (Fintype.bijective_iff_injective_and_card _).mpr
  refine ⟨hinj,(Fintype.card_le_of_injective _ hinj).antisymm ?_⟩
  rw [Fintype.card_perm,hw]
  exact hsurl.trans hle

#print axioms full_of_constant_extension

#print axioms card_map_gal_le
end
end UniformBaseChange
