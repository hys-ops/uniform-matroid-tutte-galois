import Mathlib.FieldTheory.PolynomialGaloisGroup

namespace UniformRootTranslation
open Polynomial

variable {F L : Type*} [Field F] [Field L] [Algebra F L]

/-- Translating the polynomial variable preserves its splitting fields: old roots are
obtained from new roots by adding the ground-field translation. -/
theorem isSplittingField_comp_X_add_C (p : F[X]) [IsSplittingField F L p] (a : F) :
    IsSplittingField F L (p.comp (X + C a)) := by
  constructor
  · simpa only [map_comp, Polynomial.map_add, map_X, map_C] using
      (IsSplittingField.splits L p).comp_X_add_C (algebraMap F L a)
  · rw [eq_top_iff, ← IsSplittingField.adjoin_rootSet L p, Algebra.adjoin_le_iff]
    intro x hx
    obtain ⟨hp,hx⟩ := mem_rootSet.mp hx
    let A := Algebra.adjoin F ((p.comp (X + C a)).rootSet L)
    have hy : x - algebraMap F L a ∈ (p.comp (X + C a)).rootSet L := by
      refine mem_rootSet.mpr ⟨comp_X_add_C_ne_zero_iff.mpr hp, ?_⟩
      simpa [aeval_comp] using hx
    have hmem : x - algebraMap F L a ∈ A := Algebra.subset_adjoin hy
    change x ∈ A
    simpa only [sub_add_cancel] using A.add_mem hmem (A.algebraMap_mem a)

/-- The Galois groups of a polynomial and an additive translate of its variable
are isomorphic, including the cases of inseparable polynomials and constants. -/
noncomputable def galEquiv (p : F[X]) (a : F) : (p.comp (X + C a)).Gal ≃* p.Gal := by
  letI := isSplittingField_comp_X_add_C (L := p.SplittingField) p a
  exact (IsSplittingField.algEquiv p.SplittingField (p.comp (X + C a))).symm.autCongr

theorem card_gal_comp_X_add_C (p : F[X]) (a : F) :
    Nat.card (p.comp (X + C a)).Gal = Nat.card p.Gal :=
  Nat.card_congr (galEquiv p a).toEquiv

end UniformRootTranslation
