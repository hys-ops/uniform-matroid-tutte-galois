import Mathlib.NumberTheory.RamificationInertia.HilbertTheory
import Mathlib.RingTheory.Spectrum.Maximal.Basic
import Mathlib.RingTheory.DedekindDomain.IntegralClosure
import Mathlib.RingTheory.Flat.TorsionFree

/-! Inertia containment implies unramifiedness of an intermediate affine ring.
The residue fields need only be separable; their cardinalities may be infinite. -/
namespace AffineInertiaIndex
open Ideal

section Group
variable {G B : Type*} [Group G] [CommRing B] [MulSemiringAction G B]

/-- Restricting to a subgroup that contains the original inertia loses no inertial element. -/
def inertiaEquiv (P : Ideal B) (H : Subgroup G) (hi : P.inertia G ≤ H) :
    P.inertia H ≃ P.inertia G where
  toFun σ := ⟨σ.1.1, Ideal.coe_mem_inertia.mpr σ.2⟩
  invFun σ := ⟨⟨σ.1, hi σ.2⟩, Ideal.coe_mem_inertia.mp σ.2⟩
  left_inv _ := rfl
  right_inv _ := rfl

end Group

section Tower
variable {A C B G : Type*} [CommRing A] [IsDomain A] [CommRing C] [IsDomain C]
  [CommRing B] [IsDomain B] [Algebra A C] [Algebra A B] [Algebra C B] [IsScalarTower A C B]
  [Module.Finite A B] [Module.Flat A B] [Module.Finite C B] [Module.Flat C B]
  [Group G] [Finite G] [MulSemiringAction G B] [IsGaloisGroup G A B]

/-- Over separable residue fields, the intermediate prime below P has index one
if its Galois subgroup contains the full inertia of P. -/
theorem index_eq_one_of_inertia_le (H : Subgroup G) [IsGaloisGroup H C B]
    (p : Ideal A) (q : Ideal C) (P : Ideal B) [p.IsPrime] [q.IsPrime] [P.IsPrime]
    [P.LiesOver q] [P.LiesOver p] [Algebra.HasSeparableResidueFieldsAt A B p]
    [Algebra.HasSeparableResidueFieldsAt C B q] (contain : P.inertia G ≤ H) :
    q.ramificationIdx A = 1 := by
  have ca := card_inertia_eq_ramificationIdxIn (G := G) p P
  have cc := card_inertia_eq_ramificationIdxIn (G := H) q P
  rw [ramificationIdxIn_eq_ramificationIdx p P G] at ca
  rw [ramificationIdxIn_eq_ramificationIdx q P H] at cc
  have same : P.ramificationIdx A = P.ramificationIdx C :=
    ca.symm.trans ((Nat.card_congr (inertiaEquiv P H contain)).symm.trans cc)
  apply Nat.eq_of_mul_eq_mul_right (P.ramificationIdx_pos C)
  rw [← ramificationIdx_tower (R := A) q P, one_mul, same]

/-- If H contains every finite inertia group, every maximal prime of the
intermediate affine curve has index one. -/
theorem maximal_index_eq_one (H : Subgroup G) [IsGaloisGroup H C B]
    [FaithfulSMul C B] [Algebra.IsIntegral A C]
    (contain : ∀ m : MaximalSpectrum B, m.asIdeal.inertia G ≤ H)
    (q : Ideal C) [q.IsMaximal] [Algebra.HasSeparableResidueFieldsAt A B (q.under A)]
    [Algebra.HasSeparableResidueFieldsAt C B q] : q.ramificationIdx A = 1 := by
  obtain ⟨⟨P,hP⟩⟩ := (inferInstance : Nonempty (q.primesOver B))
  let : P.IsPrime := hP.1
  let : P.LiesOver q := hP.2
  let : P.LiesOver (q.under A) := Ideal.LiesOver.trans P q (q.under A)
  have hm := IsMaximal.of_liesOver_isMaximal P q
  exact index_eq_one_of_inertia_le H (q.under A) q P (contain ⟨P,hm⟩)

end Tower
section Closures
variable (k A K L : Type*) [Field k] [CharZero k] [CommRing A] [IsDedekindDomain A]
    [Algebra k A] [Field K] [Field L] [Algebra K L] [Algebra A K] [IsFractionRing A K]
    [Algebra A L] [IsScalarTower A K L] [FiniteDimensional K L] [IsGalois K L]
    [MulSemiringAction Gal(L/K) (integralClosure A L)]
    [SMulDistribClass Gal(L/K) (integralClosure A L) L]

include k in
/-- On a characteristic-zero affine Dedekind base, the normalization in the
fixed field of a subgroup containing all finite inertia groups is unramified
at every nonzero prime. -/
theorem fixedField_index (H : Subgroup Gal(L/K))
    (contain : ∀ m : MaximalSpectrum (integralClosure A L), m.asIdeal.inertia Gal(L/K) ≤ H)
    (q : Ideal (integralClosure A (IntermediateField.fixedField H))) (hq : q.IsPrime)
    (hqn : q ≠ ⊥) : q.ramificationIdx A = 1 := by
  let E := IntermediateField.fixedField H
  let B := integralClosure A L
  let C := integralClosure A E
  let : IsDedekindDomain C := integralClosure.isDedekindDomain A K E
  let : q.IsMaximal := hq.isMaximal hqn
  let : IsFractionRing B L := integralClosure.isFractionRing_of_finite_extension (A:=A) K L
  let : IsFractionRing C E := integralClosure.isFractionRing_of_finite_extension (A:=A) K E
  let : Module.Finite A B := IsIntegralClosure.finite A K L B
  let : IsScalarTower A E L := IsScalarTower.of_algebraMap_eq (fun x => by
    rw [IsScalarTower.algebraMap_apply A K E, IsScalarTower.algebraMap_apply A K L]
    rfl)
  let cc := (IsScalarTower.toAlgHom A E L).mapIntegralClosure
  let algCB : Algebra C B := cc.toRingHom.toAlgebra
  let : IsScalarTower A C B := IsScalarTower.of_algebraMap_eq (fun x => (cc.commutes x).symm)
  let algCL : Algebra C L := ((algebraMap E L).comp (algebraMap C E)).toAlgebra
  let towerCEL : IsScalarTower C E L := IsScalarTower.of_algebraMap_eq' rfl
  let towerCBL : IsScalarTower C B L := IsScalarTower.of_algebraMap_eq (fun _ => rfl)
  let : Algebra.IsIntegral C B := Algebra.IsIntegral.tower_top A
  let : Module.Finite C B := Module.Finite.of_restrictScalars_finite A C B
  let : Module.IsTorsionFree A B := by
    rw [Module.isTorsionFree_iff_algebraMap_injective]
    apply Function.Injective.of_comp (f := algebraMap B L)
    change Function.Injective ((algebraMap B L).comp (algebraMap A B))
    rw [← IsScalarTower.algebraMap_eq, IsScalarTower.algebraMap_eq A K L]
    exact (algebraMap K L).injective.comp (IsFractionRing.injective A K)
  let : Module.IsTorsionFree C B := by
    rw [Module.isTorsionFree_iff_algebraMap_injective]
    intro x y eq
    apply Subtype.ext
    apply (algebraMap E L).injective
    exact congrArg (fun z : B => (z : L)) eq
  let : IsGaloisGroup Gal(L/K) A B := IsGaloisGroup.of_isFractionRing _ _ _ K L
  let : IsGaloisGroup H E L := IsGaloisGroup.subgroup Gal(L/K) K L H
  let : IsGaloisGroup H C B := @IsGaloisGroup.of_isFractionRing H C B E L _ _ _ _ algCB _ _ _ _ _ algCL _ _ towerCEL towerCBL _ _ _ _ _
  let : CharZero (q.under A).ResidueField := charZero_of_injective_ringHom
    (((algebraMap A (q.under A).ResidueField).comp (algebraMap k A)).injective)
  let : CharZero q.ResidueField := charZero_of_injective_ringHom
    ((((algebraMap C q.ResidueField).comp (algebraMap A C)).comp (algebraMap k A)).injective)
  exact maximal_index_eq_one H contain q

end Closures
end AffineInertiaIndex
