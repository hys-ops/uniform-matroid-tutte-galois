import UniformGalois

namespace UniformAtMinusOne
open Polynomial UniformGalois UniformBinomial UniformFibersAtRank
variable {K : Type*} [Field K] [CharZero K]

theorem first_partial_nonzero (r s : ℕ) (hr : 0 < r) (hs : 0 < s) :
    ((F K (r+s) r).derivative.eval (-1)) ≠ 0 := by
  intro h
  obtain ⟨_, _, hminus, _⟩ := UniformCritical.critical_nonzero
    (UniformCritical.F_satisfies (K := K) r s)
    (Nat.cast_ne_zero.mpr hr.ne') (Nat.cast_ne_zero.mpr hs.ne')
    (Nat.cast_ne_zero.mpr (Nat.choose_pos (Nat.le_add_right r s)).ne') h
  exact hminus (by ring)

/-- Specializing the inner parameter first at -1, two factors cannot both
vanish at x=-1. The x-partial is nonzero at this point. -/
theorem factors_do_not_covanish (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (A B : (K[X])[X]) (h : A*B = pencil K r s)
    (hA : (A.map (evalRingHom (-1 : K))).eval (-1) = 0)
    (hB : (B.map (evalRingHom (-1 : K))).eval (-1) = 0) : False := by
  let ev := evalRingHom (-1 : K)
  have hh := congrArg (fun P : (K[X])[X] => ((P.map ev).derivative).eval (-1)) h
  simp only [Polynomial.map_mul, derivative_mul, eval_add, eval_mul, map_pencil, tutteFiber,
    derivative_sub, derivative_C, sub_zero] at hh
  change (A.map ev).eval (-1) = 0 at hA
  change (B.map ev).eval (-1) = 0 at hB
  rw [hA, hB, zero_mul, mul_zero, add_zero] at hh
  exact first_partial_nonzero r s hr hs hh.symm

end UniformAtMinusOne
