import UniformCritical
import UniformFiber
import Mathlib.FieldTheory.IsAlgClosed.Basic

/-! A uniform statement about every specialization of the explicit Tutte polynomial. -/
namespace UniformFibersAtRank
open Polynomial
open UniformBinomial

variable {K : Type*} [Field K]

theorem leading_at_rank (n r : ℕ) : (F K n r).coeff r = 1 := by
  induction r with
  | zero => simp [F]
  | succ k ih =>
    rw [F, coeff_add]
    rw [← Polynomial.C_eq_natCast]
    simpa only [coeff_X_mul, coeff_C_succ, add_zero, Nat.add_one_sub_one] using ih

theorem rank_degree (n r : ℕ) : (F K n r).natDegree = r := by
  induction r with
  | zero => simp [F]
  | succ k ih =>
    have h : F K n k ≠ 0 := by
      intro he
      have e := leading_at_rank (K:=K) n k
      simp [he] at e
    rw [F, ← Polynomial.C_eq_natCast, natDegree_add_C, natDegree_X_mul h, ih]

/-- The x-polynomial at the point y = v+1, in the translated x-coordinate u=x−1. -/
noncomputable def tutteFiber (r s : ℕ) (v : K) : K[X] :=
  F K (r+s) r - C (((r+s).choose r : K) - (F K (r+s) s).eval v)

/-- On every fiber of the uniform Tutte curve there are at least r−1 distinct
geometric x-values. At most one double root can occur, even on a branch fiber. -/
theorem uniformFiberBound [CharZero K] [IsAlgClosed K] [DecidableEq K]
    (r s : ℕ) (hr : 0<r) (hs : 0<s) (v : K) :
    r ≤ (tutteFiber r s v).roots.toFinset.card + 1 := by
  let f := F K (r+s) r
  let t := ((r+s).choose r : K) - (F K (r+s) s).eval v
  have H := UniformCritical.F_satisfies (K:=K) r s
  have hr' : (r : K) ≠ 0 := Nat.cast_ne_zero.mpr hr.ne'
  have hs' : (s : K) ≠ 0 := Nat.cast_ne_zero.mpr hs.ne'
  have hc : ((r+s).choose r : K) ≠ 0 :=
    Nat.cast_ne_zero.mpr (Nat.choose_pos (Nat.le_add_right r s)).ne'
  have h₁ : ∀ a, f.derivative.eval a = 0 → f.derivative.derivative.eval a ≠ 0 :=
    fun _ h => (UniformCritical.critical_nonzero H hr' hs' hc h).2.2.2
  have h₂ : ∀ a b, f.derivative.eval a = 0 → f.derivative.eval b = 0 → f.eval a=f.eval b → a=b :=
    fun _ _ => UniformCritical.distinct_critical_values H hr' hs' hc
  have h := UniformFiber.degree_le_distinctRoots_add_one t h₁ h₂ (IsAlgClosed.splits (f - C t))
  simpa only [f,t,tutteFiber,natDegree_sub_C,rank_degree] using h

/-- Whenever a point on the plane curve has a repeated x-root, the y-direction
derivative cannot vanish there. -/
theorem transverse_at_repeated_root [CharZero K] (r s : ℕ) (hr : 0<r) (hs : 0<s)
    (u v : K) (hu : 1 < (tutteFiber r s v).rootMultiplicity u) :
    (F K (r+s) s).derivative.eval v ≠ 0 := by
  intro hv
  have h₀ := isRoot_iterate_derivative_of_lt_rootMultiplicity (n:=0)
    (by omega : 0 < (tutteFiber r s v).rootMultiplicity u)
  have h₁ := isRoot_iterate_derivative_of_lt_rootMultiplicity (n:=1) hu
  have hval : (F K (r+s) r).eval u - (((r+s).choose r : K) - (F K (r+s) s).eval v) = 0 := by
    simpa [IsRoot,tutteFiber] using h₀
  have hder : (F K (r+s) r).derivative.eval u = 0 := by
    simpa [IsRoot,tutteFiber,derivative_sub] using h₁
  exact UniformCritical.uniform_critical_values_disjoint r s hr hs hder hv (by linear_combination hval)

end UniformFibersAtRank
