import UniformFibersAtRank
import Mathlib.RingTheory.Polynomial.Morse

/-! A geometric Galois criterion for the concrete uniform Tutte pencil over K[Y].
For a splitting K[Y]-algebra, the residue root-count hypotheses of Morse's
permutation theorem are proved here, even when residue fields are not
algebraically closed. Finite-inertia generation and transitivity remain explicit. -/
namespace UniformGalois
open Polynomial UniformBinomial UniformFibersAtRank
noncomputable section

variable {K : Type*} [Field K]

/-- The outer polynomial variable is x-1 and the inner one is y-1. -/
def pencil (K : Type*) [Field K] (r s : ℕ) : (K[X])[X] :=
  (F K (r+s) r).map C - C (((r+s).choose r : K[X]) - F K (r+s) s)

private theorem map_section {k l : Type*} [Field k] [Field l]
    (g : k →+* l) (n r : ℕ) : (F k n r).map g = F l n r := by
  induction r with
  | zero => simp [F]
  | succ r ih => simp [F, ih]

private theorem map_section_value {l : Type*} [Field l] (g : K[X] →+* l) (n r : ℕ) :
    g (F K n r) = (F l n r).eval (g X) := by
  induction r with
  | zero => simp [F]
  | succ r ih => simp [F, ih]

/-- Specialization through any map from the parameter ring lands in the
explicit polynomial used for the geometric fiber computation. -/
theorem map_pencil {l : Type*} [Field l] (g : K[X] →+* l) (r s : ℕ) :
    (pencil K r s).map g = tutteFiber r s (g X) := by
  simp [pencil, tutteFiber, Polynomial.map_map, map_section, map_section_value]

theorem pencil_degree (r s : ℕ) : (pencil K r s).natDegree = r := by
  rw [pencil, natDegree_sub_C, natDegree_map_eq_of_injective C_injective, rank_degree]

private theorem fiber_bound_of_splits [CharZero K] [DecidableEq K] (r s : ℕ)
    (hr : 0<r) (hs : 0<s) (v : K) (hsplit : (tutteFiber r s v).Splits) :
    r ≤ (tutteFiber r s v).roots.toFinset.card + 1 := by
  let f := F K (r+s) r
  let t := ((r+s).choose r : K) - (F K (r+s) s).eval v
  have H := UniformCritical.F_satisfies (K:=K) r s
  have hr' : (r : K) ≠ 0 := Nat.cast_ne_zero.mpr hr.ne'
  have hs' : (s : K) ≠ 0 := Nat.cast_ne_zero.mpr hs.ne'
  have hc : ((r+s).choose r : K) ≠ 0 :=
    Nat.cast_ne_zero.mpr (Nat.choose_pos (Nat.le_add_right r s)).ne'
  have h₁ : ∀ a, f.derivative.eval a = 0 → f.derivative.derivative.eval a ≠ 0 :=
    fun _ ha => (UniformCritical.critical_nonzero H hr' hs' hc ha).2.2.2
  have h₂ : ∀ a b, f.derivative.eval a = 0 → f.derivative.eval b = 0 → f.eval a=f.eval b → a=b :=
    fun _ _ => UniformCritical.distinct_critical_values H hr' hs' hc
  have hh := UniformFiber.degree_le_distinctRoots_add_one t h₁ h₂ hsplit
  simpa only [f,t,tutteFiber,natDegree_sub_C,rank_degree] using hh

variable [CharZero K] {S : Type*} [CommRing S] [IsDomain S] [Algebra K[X] S]

/-- Every maximal ideal of any splitting algebra satisfies the collision bound
for its actual residue root set. -/
theorem residue_root_count (r s : ℕ) (hr : 0<r) (hs : 0<s)
    (hsplit : ((pencil K r s).map (algebraMap K[X] S)).Splits) (m : MaximalSpectrum S) :
    ((pencil K r s).rootSet S).ncard ≤ ((pencil K r s).rootSet (S ⧸ m.asIdeal)).ncard + 1 := by
  classical
  let : Field (S ⧸ m.asIdeal) := Ideal.Quotient.field _
  let g := algebraMap K[X] (S ⧸ m.asIdeal)
  let gc : K →+* (S ⧸ m.asIdeal) := g.comp C
  let : CharZero (S ⧸ m.asIdeal) := charZero_of_inj_zero (fun n hn => by
    apply (Nat.cast_eq_zero (R := K)).mp
    apply gc.injective
    simpa using hn)
  have hres : ((pencil K r s).map g).Splits := by
    have hh := hsplit.map (Ideal.Quotient.mk m.asIdeal)
    rwa [Polynomial.map_map] at hh
  rw [map_pencil] at hres
  have hcard := fiber_bound_of_splits r s hr hs (g X) hres
  have hmain := (pencil K r s).ncard_rootSet_le S
  rw [pencil_degree] at hmain
  refine hmain.trans ?_
  change r ≤ _ + 1
  rw [rootSet_def, aroots_def, Set.ncard_coe_finset, map_pencil]
  exact hcard

/-- If finite inertia generates the action and this action is transitive,
the permutation representation of the explicit Tutte roots is surjective. -/
theorem full_permutations_of_finite_inertia {G : Type*} [Group G]
    [MulSemiringAction G S] [SMulCommClass G K[X] S] (r s : ℕ) (hr : 0<r) (hs : 0<s)
    (hsplit : ((pencil K r s).map (algebraMap K[X] S)).Splits)
    [MulAction.IsPretransitive G ((pencil K r s).rootSet S)]
    (hgen : ⨆ m : MaximalSpectrum S, m.asIdeal.inertia G = ⊤) :
    Function.Surjective (MulAction.toPermHom G ((pencil K r s).rootSet S)) :=
  hsplit.surjective_toPermHom_of_iSup_inertia_eq_top (residue_root_count r s hr hs hsplit) hgen

end
end UniformGalois
