import UniformParameterTranslation
import UniformRootTranslation
import UniformSubsetTutte

/-! The Galois group in the actual unshifted Tutte coordinates X,y, with
the polynomial defined literally by the subset rank-nullity sum. -/
namespace UniformOrdinary
open Polynomial UniformGalois UniformFibersAtRank UniformSplitting UniformSubsetTutte
open UniformParameterTranslation
noncomputable section
variable (K : Type*) [Field K]

def y : RatFunc K := algebraMap K[X] (RatFunc K) X
def tutte (r s : ℕ) : (RatFunc K)[X] :=
  fromRank (Finset.univ : Finset (Fin (r+s))) (uniformRank r) X (C (y K))

theorem as_translate (r s : ℕ) :
    tutte K r s = (tutteFiber r s (y K-1)).comp (X+C (-1)) := by
  let e := algEquivAevalXAddC (-1 : RatFunc K)
  have he := congrArg e (exact_fiber r s (y K-1))
  change _ = e (tutteFiber r s (y K - 1))
  rw [← he]
  simp only [tutte,fromRank,map_sum,map_mul,map_pow,map_sub,map_one,map_add]
  have hx : e (X : (RatFunc K)[X]) + 1 = X := by simp [e,algEquivAevalXAddC_apply]
  have hy : e (C (y K)) = C (y K) := e.commutes (y K)
  simp only [hx,hy,sub_add_cancel]

theorem ordinary_card (r s : ℕ) : Nat.card (tutte K r s).Gal = Nat.card (generic K r s).Gal := by
  rw [as_translate, UniformRootTranslation.card_gal_comp_X_add_C]
  exact translated_parameter_card K r s

theorem ordinary_degree (r s : ℕ) : (tutte K r s).natDegree = r := by
  rw [as_translate, natDegree_comp, natDegree_X_add_C, mul_one]
  rw [y, ← shift_pencil, Polynomial.natDegree_map]
  exact UniformActual.generic_degree r s

theorem ordinary_irreducible [CharZero K] (r s : ℕ) (hr : 0<r) (hs : 0<s) :
    Irreducible (tutte K r s) := by
  rw [as_translate, y, ← shift_pencil]
  let e := (algEquivAevalXAddC (-1 : RatFunc K))
  change Irreducible (e ((Polynomial.mapEquiv (shiftParam K (-1))) (generic K r s)))
  rw [MulEquiv.irreducible_iff, MulEquiv.irreducible_iff]
  exact UniformIrreducible.uniformGenericIrreducible (K:=K) (RatFunc K) r s hr hs

theorem roots_card [CharZero K] (r s : ℕ) (hr : 0<r) (hs : 0<s) :
    Fintype.card ((tutte K r s).rootSet (tutte K r s).SplittingField) = r :=
  (Polynomial.card_rootSet_eq_natDegree (ordinary_irreducible K r s hr hs).separable
    (SplittingField.splits _)).trans (ordinary_degree K r s)

local instance splittingFact {F : Type*} [Field F] (p : F[X]) :
    Fact ((p.map (algebraMap F p.SplittingField)).Splits) := ⟨SplittingField.splits p⟩

/-- A proof of maximality for the shifted pencil yields an actual, faithful and
surjective permutation representation of the published unshifted polynomial. -/
theorem full_action_of_order [CharZero K] (r s : ℕ) (hr : 0<r) (hs : 0<s)
    (order : Nat.card (generic K r s).Gal = r.factorial) :
    Function.Bijective (Gal.galActionHom (tutte K r s) (tutte K r s).SplittingField) := by
  classical
  apply (Fintype.bijective_iff_injective_and_card _).mpr
  refine ⟨Gal.galActionHom_injective _ _,?_⟩
  rw [← Nat.card_eq_fintype_card, ordinary_card, order, Fintype.card_perm, roots_card K r s hr hs]

end
end UniformOrdinary
