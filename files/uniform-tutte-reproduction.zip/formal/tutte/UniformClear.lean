import UniformGalois
import Mathlib.Algebra.CharZero.Infinite
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.Tactic.FieldSimp

/-! Reciprocal-diagonal restriction of the bivariate uniform Tutte pencil. -/
namespace UniformClear
open Polynomial UniformBinomial UniformGalois UniformFibersAtRank
noncomputable section
variable {K : Type*} [Field K]

/-- For an outer degree d polynomial in (u,v), this polynomial in v
    restricts v^d P(v⁻¹,v) across v=0. -/
def clear (P : (K[X])[X]) : K[X] := P.reverse.eval X

theorem clear_mul (P Q : (K[X])[X]) : clear (P*Q) = clear P * clear Q := by
  simp [clear, reverse_mul_of_domain]

theorem eval_clear (P : (K[X])[X]) (z : K) (hz : z ≠ 0) :
    (clear P).eval z = z^P.natDegree * (P.map (evalRingHom z)).eval z⁻¹ := by
  let _ := invertibleOfNonzero (inv_ne_zero hz)
  have he := eval₂_reverse_mul_pow (evalRingHom z) z⁻¹ P
  have id : (clear P).eval z = P.reverse.eval₂ (evalRingHom z) z := by
    have hh := eval₂_at_apply (p:=P.reverse) (evalRingHom z) X
    simpa [clear] using hh.symm
  rw [id, eval_map]
  simp only [invOf_eq_inv, inv_inv, inv_pow] at he
  calc
    _ = z^P.natDegree * (P.reverse.eval₂ (evalRingHom z) z * (z^P.natDegree)⁻¹) := by
      field_simp
    _ = _ := by rw [he]

/-- Exact diagonal restriction for every rank and complementary rank,
    including the endpoints. -/
theorem clear_pencil [CharZero K] (r s : ℕ) :
    clear (pencil K r s) = (1+X)^(r+s) := by
  apply eq_of_infinite_eval_eq
  apply (Set.finite_singleton (0:K)).infinite_compl.mono
  intro z hz
  have h0 : z ≠ 0 := hz
  change (clear (pencil K r s)).eval z = ((1+X)^(r+s) : K[X]).eval z
  rw [eval_clear _ z h0, pencil_degree, map_pencil]
  have hh := reciprocal s r z h0
  have hc : (r+s).choose s = (r+s).choose r := by
    exact (Nat.choose_symm_of_eq_add (a:=r) (b:=s) rfl).symm
  rw [Nat.add_comm s r, hc] at hh
  simp only [tutteFiber, eval_sub, eval_C, eval_pow, eval_add, eval_X, eval_one,
    show (evalRingHom z) X=z from eval_X] 
  linear_combination hh

end
end UniformClear
