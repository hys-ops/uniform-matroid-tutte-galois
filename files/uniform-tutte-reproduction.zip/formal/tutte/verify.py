#!/usr/bin/env python3
"""Compile the source closure afresh and replay its declarations with Lean's kernel."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--mathlib", type=Path, help="an already built checkout of the pinned mathlib")
parser.add_argument("--kernel", action="store_true", help="also replay declarations from the new .olean files")
args = parser.parse_args()
env = os.environ.copy()
lean = shutil.which("lean")
if not lean:
    raise SystemExit("Lean is required; see ../../README.md")
version = subprocess.check_output([lean, "--version"], text=True).strip()
required = (root/"lean-toolchain").read_text().strip().rsplit(":v", 1)[1]
if f"version {required}," not in version:
    raise SystemExit(f"Expected Lean {required}, got {version}")
print(version, flush=True)
if args.mathlib:
    dep = args.mathlib.resolve()
    upstream = [dep/".lake/build/lib/lean", *sorted(dep.glob(".lake/packages/*/.lake/build/lib/lean"))]
else:
    upstream = [Path(p).resolve() for p in env.get("LEAN_PATH", "").split(os.pathsep) if p]
    if not upstream:
        raise SystemExit("Run with lake env or pass --mathlib /path/to/mathlib.")
upstream = [p for p in upstream if p != root and p != root/".lake/build/lib/lean"]
mods = {p.stem: p for p in root.glob("*.lean")}
order = []
seen = set()

def visit(name):
    if name in seen:
        return
    seen.add(name)
    for line in mods[name].read_text().splitlines():
        match = re.match(r"^import\s+([A-Za-z0-9_.]+)\s*$", line)
        if match and match[1] in mods:
            visit(match[1])
    order.append(name)

visit("Results")
unexpected = set(mods)-set(order)
if unexpected:
    raise SystemExit(f"Unreferenced source modules: {sorted(unexpected)}")
with tempfile.TemporaryDirectory(prefix="uniform-tutte-rebuild-") as tmp:
    env.setdefault("MALLOC_ARENA_MAX", "2")
    env["LEAN_PATH"] = os.pathsep.join([tmp]+[str(p) for p in upstream])
    log = []
    def run(command, label):
        print(label, flush=True)
        for attempt in range(3):
            res = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True)
            if res.returncode not in {-9,-11} or attempt == 2:
                break
            print(f"{label}: process ended with signal {-res.returncode}; retrying", flush=True)
            time.sleep(2)
        if res.stdout:
            print(res.stdout, end="", flush=True)
        if res.stderr:
            print(res.stderr, end="", flush=True)
        if res.returncode:
            raise SystemExit(f"{label} failed (exit {res.returncode})")
        return res.stdout+res.stderr
    for mod in order:
        src = mods[mod]
        msg = run([lean, "-j1", "-R", str(root), "-o", str(Path(tmp)/(mod+".olean")), str(src)],
                  f"compile {mod}")
        if "sorryAx" in msg:
            raise SystemExit(f"{mod}: placeholder axiom")
        if mod=="Results":
            allowed = {"propext","Classical.choice","Quot.sound"}
            for theorem, axioms in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", msg, re.S):
                extra = {x.strip() for x in axioms.split(",")} - allowed
                if extra:
                    raise SystemExit(f"{theorem}: unexpected axioms {sorted(extra)}")
                log.append(theorem)
    expected=(root/"Results.lean").read_text().count("#print axioms")
    if len(log)!=expected:
        raise SystemExit(f"Expected {expected} axiom reports; received {len(log)}.")
    if args.kernel:
        checker=shutil.which("leanchecker")
        if not checker:
            raise SystemExit("Lean distribution's leanchecker executable required")
        # Replay one module per process so multiple environments never share mapped regions.
        for mod in order:
            run([checker, "-v", mod], "kernel "+mod)
    print(f"PASS: {len(order)} modules, {len(log)} public theorem axiom audits, kernel replay={args.kernel}",flush=True)
