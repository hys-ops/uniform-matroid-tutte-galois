import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Algebra.Polynomial.Splits

/-! From simple critical points with distinct values to a bound for every
specialized fiber, expressed in terms of the polynomial's actual roots. -/

namespace UniformFiber
open Polynomial

variable {K : Type*} [Field K]

theorem fiberMultiplicity {f : K[X]} (t : K)
    (hs : ∀ a, f.derivative.eval a = 0 → f.derivative.derivative.eval a ≠ 0) (a : K) :
    (f - C t).rootMultiplicity a ≤ 2 := by
  by_contra! h
  have h₁ := isRoot_iterate_derivative_of_lt_rootMultiplicity (n := 1) (by omega : 1 < (f - C t).rootMultiplicity a)
  have h₂ := isRoot_iterate_derivative_of_lt_rootMultiplicity (n := 2) h
  have H₁ : f.derivative.eval a = 0 := by simpa [Polynomial.IsRoot, derivative_sub] using h₁
  have H₂ : f.derivative.derivative.eval a = 0 := by
    simpa [Polynomial.IsRoot, Function.iterate_succ_apply, derivative_sub] using h₂
  exact hs a H₁ H₂

theorem uniqueRepeated {f : K[X]} (t : K)
    (hi : ∀ a b, f.derivative.eval a = 0 → f.derivative.eval b = 0 → f.eval a = f.eval b → a=b)
    {a b : K} (ha : 1 < (f-C t).rootMultiplicity a) (hb : 1 < (f-C t).rootMultiplicity b) : a=b := by
  have props : ∀ x, 1 < (f-C t).rootMultiplicity x →
      f.eval x = t ∧ f.derivative.eval x = 0 := by
    intro x hx
    have h₀ := isRoot_iterate_derivative_of_lt_rootMultiplicity (n := 0) (by omega : 0 < (f-C t).rootMultiplicity x)
    have h₁ := isRoot_iterate_derivative_of_lt_rootMultiplicity (n := 1) hx
    exact ⟨by simpa [Polynomial.IsRoot, sub_eq_zero] using h₀,
      by simpa [Polynomial.IsRoot, derivative_sub] using h₁⟩
  obtain ⟨va,da⟩ := props a ha
  obtain ⟨vb,db⟩ := props b hb
  exact hi a b da db (va.trans vb.symm)


private theorem card_le_dedup_add_one {M : Type*} [DecidableEq M] [Nonempty M]
    (u : Multiset M) (h₂ : ∀ a, u.count a ≤ 2)
    (huniq : ∀ a b, 1 < u.count a → 1 < u.count b → a=b) :
    u.card ≤ u.toFinset.card + 1 := by
  classical
  obtain ⟨d, hd⟩ : ∃ d, ∀ a, 1 < u.count a → a=d := by
    by_cases h : ∃ b, 1 < u.count b
    · obtain ⟨b,hb⟩ := h
      exact ⟨b, fun a ha => huniq a b ha hb⟩
    · exact ⟨Classical.ofNonempty, fun a ha => (h ⟨a,ha⟩).elim⟩
  have hu : u ≤ u.dedup + {d} := by
    apply Multiset.le_iff_count.mpr
    intro a
    by_cases hm : a ∈ u
    · by_cases he : a=d
      · subst a
        simpa [Multiset.count_dedup, hm] using h₂ d
      · have hle : u.count a ≤ 1 := Nat.le_of_not_gt (fun h => he (hd a h))
        simpa [Multiset.count_dedup, hm, he, Ne.symm he] using hle
    · simp [Multiset.count_eq_zero.mpr hm]
  simpa [Multiset.card_toFinset] using Multiset.card_le_card hu

/-- If all critical points are simple and have distinct critical values, every
split fiber has at least (degree - 1) distinct roots, including branch fibers. -/
theorem degree_le_distinctRoots_add_one {f : K[X]} (t : K) [DecidableEq K]
    (hs : ∀ a, f.derivative.eval a = 0 → f.derivative.derivative.eval a ≠ 0)
    (hi : ∀ a b, f.derivative.eval a = 0 → f.derivative.eval b = 0 → f.eval a = f.eval b → a=b)
    (hf : (f-C t).Splits) : (f-C t).natDegree ≤ (f-C t).roots.toFinset.card + 1 := by
  rw [← splits_iff_card_roots.mp hf]
  apply card_le_dedup_add_one
  · intro a
    simpa [Polynomial.count_roots] using fiberMultiplicity t hs a
  · intro a b ha hb
    rw [Polynomial.count_roots] at ha hb
    exact uniqueRepeated t hi ha hb
end UniformFiber
