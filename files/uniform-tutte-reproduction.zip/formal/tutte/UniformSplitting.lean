import UniformGalois
import Mathlib.FieldTheory.PolynomialGaloisGroup
import Mathlib.FieldTheory.RatFunc.Basic
import Mathlib.RingTheory.Polynomial.GaussLemma
import Mathlib.RingTheory.IntegralClosure.Algebra.Basic
import Mathlib.RingTheory.Polynomial.RationalRoot

namespace UniformSplitting
open Polynomial UniformBinomial UniformFibersAtRank UniformGalois
noncomputable section

section NormalRing
variable {A M L : Type*} [CommRing A] [Field M] [Field L]
    [Algebra A M] [Algebra M L] [Algebra A L] [IsScalarTower A M L]

/-- A monic polynomial splitting in L already splits in the integral closure of
its coefficient ring inside L. -/
theorem splits_normalization (p : A[X]) (hm : p.Monic)
    (hs : (p.map (algebraMap A L)).Splits) :
    (p.map (algebraMap A (integralClosure A L))).Splits := by
  let S := integralClosure A L
  let inc : S →+* L := S.val.toRingHom
  have hinc : inc.comp (algebraMap A (integralClosure A L)) = algebraMap A L := rfl
  apply Splits.of_splits_map_of_injective (i := inc) (fun _ _ h => Subtype.ext h)
  · rwa [Polynomial.map_map]
  · intro x hx
    have hco : x ∈ p.aroots L := by simpa only [Polynomial.map_map, hinc, aroots_def] using hx
    exact ⟨⟨x, roots_mem_integralClosure hm hco⟩, rfl⟩

/-- For a normal extension of the generic field, irreducibility gives
transitivity on the actual integral roots. -/
theorem transitive_normalization [Normal M L] (p : A[X]) (hp : Irreducible (p.map (algebraMap A M))) :
    MulAction.IsPretransitive (L ≃ₐ[M] L) (p.rootSet (integralClosure A L)) := by
  constructor
  intro x y
  have hroot (q : p.rootSet (integralClosure A L)) :
      aeval (q.val.val : L) (p.map (algebraMap A M)) = 0 := by
    rw [← aeval_eq_aeval_map (IsScalarTower.algebraMap_eq A M L).symm]
    have := aeval_eq_zero_of_mem_rootSet q.property
    have hco := congrArg (fun z : integralClosure A L => (z:L)) this
    simpa only [Subalgebra.aeval_coe, ZeroMemClass.coe_zero] using hco
  have hx := minpoly.eq_of_irreducible hp (hroot x)
  have hy := minpoly.eq_of_irreducible hp (hroot y)
  obtain ⟨g,hg⟩ := (Normal.minpoly_eq_iff_mem_orbit (F := M) L).mp (hy.symm.trans hx)
  refine ⟨g, Subtype.ext (Subtype.ext ?_)⟩
  exact hg

end NormalRing

variable {K : Type*} [Field K] [CharZero K]

omit [CharZero K] in
theorem pencil_monic (r s : ℕ) (hr : 0 < r) : (pencil K r s).Monic := by
  rw [Monic.def, leadingCoeff, pencil_degree, pencil, coeff_sub, coeff_C]
  simp [hr.ne', leading_at_rank]

abbrev generic (K : Type*) [Field K] (r s : ℕ) : (RatFunc K)[X] :=
  (pencil K r s).map (algebraMap K[X] (RatFunc K))

abbrev splitting (K : Type*) [Field K] (r s : ℕ) := (generic K r s).SplittingField

abbrev normalization (K : Type*) [Field K] (r s : ℕ) :=
  integralClosure K[X] (splitting K r s)

/-- In the actual geometric splitting field only the generation by finite inertia
and the algebraic irreducibility of the bivariate pencil are required here. -/
theorem actual_full_permutations (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (hirr : Irreducible (pencil K r s))
    (hgen : ⨆ m : MaximalSpectrum (normalization K r s),
      m.asIdeal.inertia (splitting K r s ≃ₐ[RatFunc K] splitting K r s) = ⊤) :
    Function.Surjective (MulAction.toPermHom (splitting K r s ≃ₐ[RatFunc K] splitting K r s)
      ((pencil K r s).rootSet (normalization K r s))) := by
  have hm := pencil_monic (K := K) r s hr
  have hi := (hm.irreducible_iff_irreducible_map_fraction_map (K := RatFunc K)).mp hirr
  let := transitive_normalization (M := RatFunc K) (L := splitting K r s) _ hi
  apply full_permutations_of_finite_inertia r s hr hs _ hgen
  apply splits_normalization _ hm
  have hsp := SplittingField.splits (generic K r s)
  change (((pencil K r s).map (algebraMap K[X] (RatFunc K))).map
    (algebraMap (RatFunc K) (splitting K r s))).Splits at hsp
  rwa [Polynomial.map_map, ← IsScalarTower.algebraMap_eq] at hsp

end
end UniformSplitting
