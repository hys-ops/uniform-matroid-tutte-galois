import UniformSplitting
import UniformIrreducible
import Mathlib.Data.Fintype.EquivFin

namespace UniformActual

open Polynomial UniformSplitting UniformGalois
noncomputable section
variable {K : Type*} [Field K] [CharZero K]

omit [CharZero K] in
theorem generic_degree (r s : ℕ) : (generic K r s).natDegree = r := by
  rw [generic, natDegree_map_eq_of_injective (IsFractionRing.injective _ _), pencil_degree]

theorem field_root_count (r s : ℕ) (hr : 0 < r) (hs : 0 < s) :
    Fintype.card ((generic K r s).rootSet (splitting K r s)) = r := by
  have hi := UniformIrreducible.uniformGenericIrreducible (K := K) (RatFunc K) r s hr hs
  exact (card_rootSet_eq_natDegree hi.separable (SplittingField.splits (generic K r s))).trans
    (generic_degree r s)

private theorem normalization_root_count (r s : ℕ) (hr : 0 < r) (hs : 0 < s) :
    ((pencil K r s).rootSet (normalization K r s)).ncard = r := by
  let L := splitting K r s
  let Z := normalization K r s
  let P := pencil K r s
  have hm : P.Monic := pencil_monic r s hr
  have hmL : (P.map (algebraMap K[X] L)).Splits := by
    have H := SplittingField.splits (generic K r s)
    change ((P.map (algebraMap K[X] (RatFunc K))).map (algebraMap (RatFunc K) L)).Splits at H
    rwa [Polynomial.map_map, ← IsScalarTower.algebraMap_eq] at H
  have hmZ := splits_normalization P hm hmL
  let i : Z →ₐ[K[X]] L := (integralClosure K[X] L).val
  have he := hmZ.image_rootSet_of_map_ne_zero i (hm.map _).ne_zero
  have H : (P.rootSet Z).ncard = (P.rootSet L).ncard := by
    rw [← he]
    exact (Set.ncard_image_of_injective _ (show Function.Injective i from fun _ _ h => Subtype.ext h)).symm
  refine H.trans ?_
  have heq : P.rootSet L = (generic K r s).rootSet L := by
    classical
    simp only [rootSet_def, aroots_def, generic, Polynomial.map_map, ← IsScalarTower.algebraMap_eq]
    rfl
  rw [heq, ← Nat.card_coe_set_eq, Nat.card_eq_fintype_card]
  exact field_root_count r s hr hs

omit [CharZero K] in
/-- The splitting-field automorphism group acts faithfully on its usual roots;
the action here acts literally on field elements. -/
private theorem faithful_field_action (r s : ℕ) :
    Function.Injective (MulAction.toPermHom (splitting K r s ≃ₐ[RatFunc K] splitting K r s)
      ((generic K r s).rootSet (splitting K r s))) := by
  intro g h gh
  apply Polynomial.Gal.ext (generic K r s)
  intro x hx
  let z : (generic K r s).rootSet (splitting K r s) := ⟨x,hx⟩
  have hz := congrArg (fun e : Equiv.Perm ((generic K r s).rootSet (splitting K r s)) => e z) gh
  exact congrArg Subtype.val hz

/-- The precise remaining input for all ranks is generation by the finite inertia groups.
Under it the natural Galois action on the ordinary splitting-field roots is bijective. -/
theorem actual_root_action_of_inertia (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (hgen : ⨆ m : MaximalSpectrum (normalization K r s),
      m.asIdeal.inertia (splitting K r s ≃ₐ[RatFunc K] splitting K r s) = ⊤) :
    Function.Bijective (MulAction.toPermHom (splitting K r s ≃ₐ[RatFunc K] splitting K r s)
      ((generic K r s).rootSet (splitting K r s))) := by
  classical
  let G := splitting K r s ≃ₐ[RatFunc K] splitting K r s
  let Ω := (generic K r s).rootSet (splitting K r s)
  let Z := (pencil K r s).rootSet (normalization K r s)
  have hi := UniformIrreducible.uniformAbsolutelyIrreducible (K := K) r s hr hs
  have hinj := faithful_field_action (K := K) r s
  have hsur := actual_full_permutations r s hr hs hi hgen
  apply (Fintype.bijective_iff_injective_and_card _).mpr
  refine ⟨hinj, (Fintype.card_le_of_injective _ hinj).antisymm ?_⟩
  have hz : Fintype.card Z = r := by
    rw [← Nat.card_eq_fintype_card, Nat.card_coe_set_eq]
    exact normalization_root_count r s hr hs
  have hw := field_root_count (K := K) r s hr hs
  have hh := Fintype.card_le_of_surjective _ hsur
  change Fintype.card (Equiv.Perm Z) ≤ Fintype.card G at hh
  simpa only [Fintype.card_perm, hz, hw] using hh

/-- Unconditional S₂ on the two actual roots for every positive corank. -/
theorem rank_two_root_action (s : ℕ) (hs : 0 < s) :
    Function.Bijective (MulAction.toPermHom (splitting K 2 s ≃ₐ[RatFunc K] splitting K 2 s)
      ((generic K 2 s).rootSet (splitting K 2 s))) := by
  classical
  have hi := UniformIrreducible.uniformGenericIrreducible (K := K) (RatFunc K) 2 s (by decide) hs
  have hd := generic_degree (K := K) 2 s
  have hdiv := Polynomial.Gal.prime_degree_dvd_card hi (by change Nat.Prime (generic K 2 s).natDegree; rw [hd]; exact Nat.prime_two)
  change (generic K 2 s).natDegree ∣ Nat.card (generic K 2 s).Gal at hdiv
  rw [hd, Nat.card_eq_fintype_card] at hdiv
  have hle := Nat.le_of_dvd Fintype.card_pos hdiv
  have hinj := faithful_field_action (K := K) 2 s
  apply (Fintype.bijective_iff_injective_and_card _).mpr
  refine ⟨hinj, (Fintype.card_le_of_injective _ hinj).antisymm ?_⟩
  have hw := field_root_count (K := K) 2 s (by decide) hs
  rw [Fintype.card_perm, hw]
  exact hle

/-- The actual rank-two Galois group is isomorphic to the full symmetric group. -/
def rank_two_galois (s : ℕ) (hs : 0 < s) :
    (splitting K 2 s ≃ₐ[RatFunc K] splitting K 2 s) ≃* Equiv.Perm (Fin 2) :=
  (MulEquiv.ofBijective _ (rank_two_root_action s hs)).trans
    (Fintype.equivFinOfCardEq (field_root_count (K := K) 2 s (by decide) hs)).permCongrHom

end
end UniformActual
