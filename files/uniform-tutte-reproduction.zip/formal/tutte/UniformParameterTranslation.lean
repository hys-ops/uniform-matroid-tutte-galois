import UniformBaseChange

/-! Changes of coefficient coordinates do not change the size of the
splitting-field Galois group. Specialize to y ↦ y−1 in the uniform pencil. -/
namespace UniformParameterTranslation
open Polynomial UniformGalois UniformFibersAtRank UniformSplitting
noncomputable section

private theorem card_map_hom_le {F E : Type*} [Field F] [Field E] (f : F →+* E) (p : F[X]) :
    Nat.card (p.map f).Gal ≤ Nat.card p.Gal := by
  let : Algebra F E := f.toAlgebra
  exact UniformBaseChange.card_map_gal_le p

theorem card_map_equiv {F E : Type*} [Field F] [Field E] (e : F ≃+* E) (p : F[X]) :
    Nat.card (p.map e.toRingHom).Gal = Nat.card p.Gal := by
  apply (card_map_hom_le e.toRingHom p).antisymm
  have h := card_map_hom_le e.symm.toRingHom (p.map e.toRingHom)
  have he : e.symm.toRingHom.comp e.toRingHom = RingHom.id F := by ext x; exact e.symm_apply_apply x
  simpa only [Polynomial.map_map, he, Polynomial.map_id] using h

variable (K : Type*) [Field K]

/-- The field automorphism induced by translating the polynomial parameter. -/
def shiftParam (a : K) : RatFunc K ≃+* RatFunc K :=
  IsFractionRing.ringEquivOfRingEquiv (Polynomial.algEquivAevalXAddC a).toRingEquiv

/-- Identify our coefficient-field translation with literal substitution in the fiber. -/
theorem shift_pencil (r s : ℕ) :
    (generic K r s).map (shiftParam K (-1)).toRingHom =
      tutteFiber r s (algebraMap K[X] (RatFunc K) X - 1) := by
  rw [generic, Polynomial.map_map, map_pencil]
  congr 1
  change IsFractionRing.ringEquivOfRingEquiv (Polynomial.algEquivAevalXAddC (-1:K)).toRingEquiv
    (algebraMap K[X] (RatFunc K) X) = _
  rw [IsFractionRing.ringEquivOfRingEquiv_algebraMap]
  simp [sub_eq_add_neg]

theorem translated_parameter_card (r s : ℕ) :
    Nat.card (tutteFiber r s (algebraMap K[X] (RatFunc K) X - 1)).Gal =
      Nat.card (generic K r s).Gal := by
  rw [← shift_pencil]
  exact card_map_equiv _ _

end
end UniformParameterTranslation
