import Mathlib.RingTheory.Smooth.Fiber
import Mathlib.RingTheory.RamificationInertia.Ramification
import Mathlib.RingTheory.DedekindDomain.IntegralClosure
import Mathlib.FieldTheory.RatFunc.AsPolynomial

/-! In characteristic zero the residue extensions at finite places are separable.
For a finite flat algebra over a Noetherian ring this converts index one at every
maximal ideal to étaleness; the integral closure of k[t] is a particular case. -/
namespace AffineEtaleBridge
open Polynomial

/-- All residue extensions in an integral algebra over a characteristic-zero
field algebra are separable, even where the affine prime is not maximal. -/
theorem residuesSeparable (k A B : Type*) [Field k] [CharZero k]
    [CommRing A] [Algebra k A] [CommRing B] [Algebra A B] [Algebra.IsIntegral A B]
    (r : Ideal A) [r.IsPrime] : Algebra.HasSeparableResidueFieldsAt A B r := by
  let f : k →+* r.ResidueField :=
    (algebraMap A r.ResidueField).comp (algebraMap k A)
  have : CharZero r.ResidueField := charZero_of_injective_ringHom f.injective
  infer_instance

theorem etale_of_maximal_ramification_one (k A B : Type*) [Field k] [CharZero k]
    [CommRing A] [Algebra k A] [IsNoetherianRing A]
    [CommRing B] [Algebra A B] [Module.Finite A B] [Module.Flat A B]
    (he : ∀ (q : Ideal B) (_ : q.IsMaximal), q.ramificationIdx A = 1) :
    Algebra.Etale A B := by
  have : Algebra.FormallyUnramified A B := by
    rw [Algebra.formallyUnramified_iff_forall]
    intro x
    obtain ⟨q,hq,hxq⟩ := Ideal.exists_le_maximal x.asIdeal x.isPrime.ne_top
    let y : PrimeSpectrum B := ⟨q,hq.isPrime⟩
    have : q.IsPrime := hq.isPrime
    have := residuesSeparable k A B (q.under A)
    have hloc : y ∈ Algebra.unramifiedLocus A B := by
      exact Ideal.ramificationIdx_eq_one_iff.mp (he _ hq)
    exact (Algebra.isOpen_unramifiedLocus (R:=A) (A:=B)).stableUnderGeneralization
      ((PrimeSpectrum.le_iff_specializes x y).mp hxq) hloc
  have : Algebra.FinitePresentation A B := Algebra.FinitePresentation.of_finiteType.mp inferInstance
  exact Algebra.Etale.of_formallyUnramified_of_flat

/-- Maximal-ideal version, suitable for the fixed field of a subgroup
containing every finite inertia group. -/
theorem integralClosure_etale_of_maximal (k E : Type*) [Field k] [CharZero k] [Field E]
    [Algebra (RatFunc k) E] [FiniteDimensional (RatFunc k) E]
    [Algebra k[X] E] [IsScalarTower k[X] (RatFunc k) E]
    (he : ∀ (q : Ideal (integralClosure k[X] E)) (_ : q.IsMaximal),
      q.ramificationIdx k[X] = 1) :
    Algebra.Etale k[X] (integralClosure k[X] E) := by
  let B := integralClosure k[X] E
  let : Module.Finite k[X] B := IsIntegralClosure.finite k[X] (RatFunc k) E B
  have : Module.IsTorsionFree k[X] E := by
    rw [Module.isTorsionFree_iff_algebraMap_injective,IsScalarTower.algebraMap_eq k[X] (RatFunc k) E]
    exact (algebraMap (RatFunc k) E).injective.comp (IsFractionRing.injective k[X] (RatFunc k))
  let : Module.Free k[X] B := IsIntegralClosure.module_free k[X] (RatFunc k) E B
  exact etale_of_maximal_ramification_one k k[X] B he

/-- A finite extension of the rational function field gives an étale integral
closure over the affine line if all its nonzero prime ideals have index one. -/
theorem integralClosure_etale (k E : Type*) [Field k] [CharZero k] [Field E]
    [Algebra (RatFunc k) E] [FiniteDimensional (RatFunc k) E]
    [Algebra k[X] E] [IsScalarTower k[X] (RatFunc k) E]
    (he : ∀ (q : Ideal (integralClosure k[X] E)) (_ : q.IsPrime),
      q ≠ ⊥ → q.ramificationIdx k[X] = 1) :
    Algebra.Etale k[X] (integralClosure k[X] E) := by
  let B := integralClosure k[X] E
  have : Module.IsTorsionFree k[X] E := by
    rw [Module.isTorsionFree_iff_algebraMap_injective,IsScalarTower.algebraMap_eq k[X] (RatFunc k) E]
    exact (algebraMap (RatFunc k) E).injective.comp (IsFractionRing.injective k[X] (RatFunc k))
  apply integralClosure_etale_of_maximal k E
  intro q hq
  apply he q hq.isPrime
  apply Ring.ne_bot_of_isMaximal_of_not_isField hq
  intro hfield
  have hR := isField_of_isIntegral_of_isField (R:=k[X]) (S:=B)
    (FaithfulSMul.algebraMap_injective k[X] B) hfield
  exact Polynomial.not_isField k hR

#print axioms integralClosure_etale
end AffineEtaleBridge
