import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.EraseLead
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Tactic.Ring

/-! The polynomial case of the reflection criterion. Only characteristic zero
is imposed on the coefficient field. -/

namespace ReflectionPolynomial
open Polynomial
open scoped BigOperators
variable {K : Type*} [Field K] [CharZero K]

omit [CharZero K] in
private theorem coeff_pow_sub (V W : K[X]) (a b : ℕ) (hV : V ≠ 0) (hW : W ≠ 0)
    (vd : V.natDegree = b) (wd : W.natDegree = b) (lc : W.leadingCoeff = V.leadingCoeff) :
    (V^a-W^a).coeff ((a-1)*b+(V-W).natDegree) =
      (a:K)*V.leadingCoeff^(a-1)*(V-W).leadingCoeff := by
  let t := fun i : ℕ => V^i*W^(a-1-i)
  have dt (i : ℕ) (hi : i ∈ Finset.range a) : (t i).natDegree=(a-1)*b := by
    have h : i+(a-1-i)=a-1 := by have := Finset.mem_range.mp hi; omega
    dsimp [t]
    rw [natDegree_mul (pow_ne_zero _ hV) (pow_ne_zero _ hW), natDegree_pow, natDegree_pow,
      vd,wd,← Nat.add_mul,h]
  have lcT (i : ℕ) (hi : i ∈ Finset.range a) : (t i).coeff ((a-1)*b)=V.leadingCoeff^(a-1) := by
    have h : i+(a-1-i)=a-1 := by have := Finset.mem_range.mp hi; omega
    rw [← dt i hi,coeff_natDegree]
    dsimp [t]
    rw [leadingCoeff_mul,leadingCoeff_pow,leadingCoeff_pow,lc,←pow_add,h]
  have cb : (∑ i ∈ Finset.range a,t i).coeff ((a-1)*b) = (a:K)*V.leadingCoeff^(a-1) := by
    rw [finsetSum_coeff]
    calc ∑ i ∈ Finset.range a, (t i).coeff ((a-1)*b) =
          ∑ _i ∈ Finset.range a, V.leadingCoeff^(a-1) := Finset.sum_congr rfl lcT
      _ = _ := by simp [nsmul_eq_mul]
  rw [← geom_sum₂_mul]
  change ((∑ i ∈ Finset.range a,t i)*(V-W)).coeff _ = _
  rw [coeff_mul_add_eq_of_natDegree_le
    (natDegree_sum_le_of_forall_le _ t (fun i hi => (dt i hi).le)) le_rfl,cb,coeff_natDegree]

omit [CharZero K] in
/-- For two polynomials of equal degree and leading coefficient, the first
noncanceling term in the difference of their powers persists under composition. -/
theorem comp_difference_coefficient (U V W : K[X]) (hV : V ≠ 0) (hW : W ≠ 0)
    (wd : W.natDegree = V.natDegree) (lc : W.leadingCoeff = V.leadingCoeff)
    (hd : 0 < (V-W).natDegree) :
    (U.comp V - U.comp W).coeff ((U.natDegree-1)*V.natDegree + (V-W).natDegree) =
      U.leadingCoeff * ((U.natDegree:K)*V.leadingCoeff^(U.natDegree-1)*(V-W).leadingCoeff) := by
  let N := (U.natDegree-1)*V.natDegree+(V-W).natDegree
  have small (Z : K[X]) (zz : Z.natDegree=V.natDegree) : (U.eraseLead.comp Z).coeff N=0 := by
    apply coeff_eq_zero_of_natDegree_lt
    rw [natDegree_comp,zz]
    dsimp [N]
    exact lt_of_le_of_lt (Nat.mul_le_mul_right _ U.eraseLead_natDegree_le) (by omega)
  have split (Z : K[X]) : U.comp Z = U.eraseLead.comp Z + C U.leadingCoeff*Z^U.natDegree := by
    simpa only [add_comp,mul_comp,C_comp,pow_comp,X_comp] using
      congrArg (fun P : K[X] => P.comp Z) U.eraseLead_add_C_mul_X_pow.symm
  change (U.comp V - U.comp W).coeff N = _
  rw [split V,split W,coeff_sub,coeff_add,coeff_add,small V rfl,small W wd,
    zero_add,zero_add,coeff_C_mul,coeff_C_mul,← mul_sub,← coeff_sub,
    coeff_pow_sub V W _ _ hV hW rfl wd lc]

/-- A nonzero linear reflection difference suffices to rule out a decomposition
into two nonlinear polynomials. -/
theorem indecomposable_of_reflection_linear {P U V : K[X]} {a : K} (ha : a ≠ 0)
    (h : P - P.comp (-X) = C a * X) (hcomp : P = U.comp V) :
    U.natDegree ≤ 1 ∨ V.natDegree ≤ 1 := by
  by_contra! hn
  obtain ⟨hu,hv⟩ := hn
  let W := V.comp (-X)
  have he : U.comp V - U.comp W = C a*X := by
    simpa only [hcomp,comp_assoc,W] using h
  have hnz : C a*X ≠ (0:K[X]) := mul_ne_zero (C_ne_zero.mpr ha) X_ne_zero
  have dvd : V-W ∣ U.comp V-U.comp W := by
    simpa only [eval_map,Polynomial.comp] using sub_dvd_eval_sub V W (U.map C)
  have hD : (V-W).natDegree ≤ 1 := by
    rw [he] at dvd
    simpa only [natDegree_C_mul ha,natDegree_X] using natDegree_le_of_dvd dvd hnz
  have hD0 : (V-W).coeff 0 = 0 := by
    rw [coeff_zero_eq_eval_zero]; simp [W]
  have dpos : 0 < (V-W).natDegree := by
    by_contra! hzero
    have hz := eq_C_of_natDegree_eq_zero (Nat.eq_zero_of_le_zero hzero)
    rw [hD0,map_zero] at hz
    have hw := sub_eq_zero.mp hz
    exact hnz (by rw [← he,hw,sub_self])
  have wd : W.natDegree=V.natDegree := by simp [W,natDegree_comp]
  have vnon := ne_zero_of_natDegree_gt (show 0<V.natDegree by omega)
  have wnon := ne_zero_of_natDegree_gt (show 0<W.natDegree by omega)
  have lc : W.leadingCoeff=V.leadingCoeff := by
    have hz := coeff_eq_zero_of_natDegree_lt (show (V-W).natDegree<V.natDegree by omega)
    rw [coeff_sub,coeff_natDegree,← wd,coeff_natDegree] at hz
    exact (sub_eq_zero.mp hz).symm
  have cn := comp_difference_coefficient U V W vnon wnon wd lc dpos
  have hi : 1 < (U.natDegree-1)*V.natDegree + (V-W).natDegree := by
    have hh : V.natDegree ≤ (U.natDegree-1)*V.natDegree :=
      Nat.le_mul_of_pos_left _ (by omega)
    omega
  rw [he,coeff_eq_zero_of_natDegree_lt (by simpa only [natDegree_C_mul ha,natDegree_X] using hi)] at cn
  exact (mul_ne_zero (leadingCoeff_ne_zero.mpr (ne_zero_of_natDegree_gt (by omega)))
    (mul_ne_zero (mul_ne_zero (Nat.cast_ne_zero.mpr (by omega))
      (pow_ne_zero _ (leadingCoeff_ne_zero.mpr vnon)))
      (leadingCoeff_ne_zero.mpr (ne_zero_of_natDegree_gt dpos)))) cn.symm

#print axioms indecomposable_of_reflection_linear
end ReflectionPolynomial
