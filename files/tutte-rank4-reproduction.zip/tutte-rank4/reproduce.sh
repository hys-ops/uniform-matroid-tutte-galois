#!/usr/bin/env bash
set -euo pipefail
source_dir="$(cd "$(dirname "$0")" && pwd)"
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
cp "$source_dir"/*.lean "$work/"
cd "$work"
export LEAN_PATH="$work${LEAN_PATH:+:$LEAN_PATH}"
lean --version
for module in ReflectionPolynomial UniformBinomial TutteQuartic; do
  lean -DwarningAsError=true -o "$module.olean" "$module.lean"
done
lean -DwarningAsError=true Check.lean
