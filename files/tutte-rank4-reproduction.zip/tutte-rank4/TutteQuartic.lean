import UniformBinomial
import ReflectionPolynomial
import Mathlib.Data.Nat.Choose.Cast
import Mathlib.Algebra.Polynomial.Roots

open Polynomial
open scoped Polynomial

namespace TutteQuartic
variable {K : Type*} [Field K] [CharZero K]
local instance : NeZero (2 : K) := ⟨by norm_num⟩
local instance : Infinite K := Infinite.of_injective (fun n : ℕ => (n : K)) Nat.cast_injective

private noncomputable def shift (n : ℕ) : K[X] := X - C ((n : K) / 4)

private theorem choose_three (n : ℕ) (hn : 4 < n) :
    (n.choose 3 : K) = (n : K) * ((n : K) - 1) * ((n : K) - 2) / 6 := by
  have h : (n.choose 3 : K) * 3 = (n.choose 2 : K) * ((n - 2 : ℕ) : K) := by
    exact_mod_cast Nat.choose_succ_right_eq n 2
  rw [Nat.cast_choose_two K n, Nat.cast_sub (by omega : 2 ≤ n)] at h
  push_cast at h
  linear_combination h / 3

private theorem eval_F_four (n : ℕ) (hn : 4 < n) (x : K) :
    (UniformBinomial.F K n 4).eval x =
      x^4 + (n : K)*x^3 + ((n : K)*((n : K)-1)/2)*x^2 +
      ((n : K)*((n : K)-1)*((n : K)-2)/6)*x + (n.choose 4 : K) := by
  simp only [UniformBinomial.F, eval_add, eval_mul, eval_X, eval_natCast,
    eval_one, choose_three n hn]
  rw [Nat.choose_one_right, Nat.cast_choose_two K n]
  ring

theorem reflection (n : ℕ) (hn : 4 < n) :
    let P := (UniformBinomial.F K n 4).comp (shift n)
    P - P.comp (-X) = C ((n : K)*((n : K)-2)*((n : K)-4)/12)*X := by
  dsimp only
  apply Polynomial.funext
  intro x
  simp only [shift, eval_sub, eval_comp, eval_neg, eval_X, eval_C, eval_mul,
    eval_F_four n hn]
  ring

theorem indecomposable (n : ℕ) (hn : 4 < n) (U V : K[X])
    (h : U.comp V = UniformBinomial.F K n 4) :
    U.natDegree ≤ 1 ∨ V.natDegree ≤ 1 := by
  have hn0 : (n : K) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hn2 : (n : K)-2 ≠ 0 := by
    rw [← Nat.cast_ofNat, ← Nat.cast_sub (by omega : 2 ≤ n)]
    exact Nat.cast_ne_zero.mpr (by omega)
  have hn4 : (n : K)-4 ≠ 0 := by
    rw [← Nat.cast_ofNat, ← Nat.cast_sub (by omega : 4 ≤ n)]
    exact Nat.cast_ne_zero.mpr (by omega)
  have ha := div_ne_zero (mul_ne_zero (mul_ne_zero hn0 hn2) hn4)
    (by norm_num : (12 : K) ≠ 0)
  have hcomp : (UniformBinomial.F K n 4).comp (shift n) =
      U.comp (V.comp (shift n)) := by
    rw [← h, comp_assoc]
  have hi := ReflectionPolynomial.indecomposable_of_reflection_linear ha (reflection n hn) hcomp
  simpa [shift, natDegree_comp] using hi

theorem no_quadratic_pair (n : ℕ) (hn : 4 < n) (U V : K[X])
    (hU : U.natDegree = 2) (hV : V.natDegree = 2) :
    U.comp V ≠ UniformBinomial.F K n 4 := by
  intro h
  have h' := indecomposable n hn U V h
  omega

#print axioms reflection
#print axioms no_quadratic_pair
end TutteQuartic
