import TutteQuartic

open Polynomial
open scoped Polynomial

example {K : Type*} [Field K] [CharZero K] (n : ℕ) (hn : 4 < n) (U V : K[X])
    (hU : U.natDegree = 2) (hV : V.natDegree = 2) :
    U.comp V ≠ UniformBinomial.F K n 4 :=
  TutteQuartic.no_quadratic_pair n hn U V hU hV

#print axioms TutteQuartic.indecomposable
