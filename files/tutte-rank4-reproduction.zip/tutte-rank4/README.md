# Rank-four uniform Tutte cover: Lean reproduction

The original successful standalone check used Lean 4.33.1 and Mathlib commit
0df444a360eaa60ab8c11dca51a86af692955474. The archive includes the Euler
reflection lemma, the Tutte binomial-section definition, the specialization,
an import check, and the output from the strict build.

Use the specified Lean release in a Mathlib project at the stated revision,
with its dependencies compiled. From that project, run
`lake env bash /path/to/reproduce.sh` (replace the illustrative path with the
location of the unpacked archive). The script builds the three modules in
dependency order and tests the exported theorem from a separate import.

This is not a rerun of the distinct all-rank Tutte Galois development.
